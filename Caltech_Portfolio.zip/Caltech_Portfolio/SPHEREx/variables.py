# Camera control code
# Variables.py
# 10/20/2023

# from pixelinkWrapper import *

# Image location
folder = "./subtracted/" # Self-explanitory, make sure slash is on the end
subtracted = "./subtracted/"
bw = "./bw_output/"
filename = "image" # Filename (as in filename###.format)
format = "jpeg"  # Replace this with the format you want
prefix = "bw_" # Prefix for the B/W image conversion

# Photo/Stack settings
num = 1 # Number of photos
stack = True
stack_num = 3 # Optional, number of exposures per main photo
stack_folders = False # Put each set of photos into a folder, True or False. True makes the organization much easier
organize = True
stacked_image_folder = "stacked/"



# Image format code
# Just edit the format above (no period before it [i.e. "jpeg" not ".jpeg"]) to change output format
"""FORMATS = {
    "jpg": PxLApi.ImageFormat.JPEG,
    "jpeg": PxLApi.ImageFormat.JPEG,
    "png": PxLApi.ImageFormat.PNG,
    "bmp": PxLApi.ImageFormat.BMP,
}
pxlformat = FORMATS[format.lower()]"""

# Camera number
camera = 0 # Do not change this unless there are multiple cameras

# B/W filter level
bw_filter = [30, 30, 30]