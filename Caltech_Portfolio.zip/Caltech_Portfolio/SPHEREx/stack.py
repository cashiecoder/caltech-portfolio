import os
import cv2
import numpy as np
import variables as var

def init():
    # Provide the directory path where your image files are located
    root_directory = var.folder

    # Create a dictionary to store image paths for each directory
    image_paths_dict = {}

    if var.stack_folders == True:
        # Iterate through directories in the root directory
        for root, directories, _ in os.walk(root_directory):
            for directory in directories:
                if var.filename in directory.lower():  # Check if "file" is in the directory name
                    directory_path = os.path.join(root, directory)
                    image_paths = []
                    for file in os.listdir(directory_path):
                        if file.endswith(var.format):
                            # Construct the full file path and append it to the list
                            path = os.path.join(directory_path, file)
                            image_paths.append(path)
                    if image_paths:
                        image_paths_dict[directory] = image_paths
    else:
        image_paths = []
        for file in os.listdir(root_directory):
            if file.endswith(var.format):
                # Construct the full file path and append it to the list
                path = os.path.join(root_directory, file)
                image_paths.append(path)
        if image_paths:
            image_paths_dict[root_directory] = image_paths
            
    return image_paths_dict

def stack(image_paths_dict):
    for directory, image_paths in image_paths_dict.items():
        if not image_paths:
            print(f"No valid image paths found in {directory}.")
            continue

        # Load your images
        images = [cv2.imread(path, cv2.IMREAD_UNCHANGED) for path in image_paths]

        if not all(img is not None for img in images):
            print(f"Some images in {directory} could not be loaded.")
            continue

        """# Apply brightness and contrast adjustment
        alpha = 4.0  # Brightness factor
        beta = 50   # Contrast factor
        adjusted_images = [cv2.convertScaleAbs(img, alpha=alpha, beta=beta) for img in images]

        # Apply gamma correction
        gamma = 1.5
        gamma_corrected_images = [np.power(img / 255.0, gamma) * 255 for img in adjusted_images]"""

        # Convert images to floating-point format
        images_float = [img.astype(np.float32) for img in images]

        # Stack the images to increase brightness
        stacked_image = np.sum(images_float, axis=0) / len(images)

        # Ensure the values are within the valid range (0-255)
        stacked_image = np.clip(stacked_image, 0, 255).astype(np.uint8)

        # Get the common filename prefix from the first image path in the directory
        common_filename_prefix = os.path.basename(image_paths[0]).rsplit("_", 1)[0]

        if var.stack_folders == True:
            # Save the resulting stacked image in the same directory as the source images
            output_directory = os.path.dirname(os.path.dirname(image_paths[0]))
        else:
            # Save the resulting stacked image one level up in the directory tree
            output_directory = os.path.dirname(image_paths[0])
        
        output_filename = os.path.join(output_directory, common_filename_prefix + "_stacked." + var.format)
        cv2.imwrite(output_filename, stacked_image)

def main():
    image_paths_dict = init()
    stack(image_paths_dict)
