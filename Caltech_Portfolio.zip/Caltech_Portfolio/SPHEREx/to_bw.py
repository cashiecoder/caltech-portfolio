# Camera control code
# to_bw.py
# 10/20/2023

import cv2
import numpy as np
import os
import variables as var

def main(image_path, file):
    # Load the image
    image = cv2.imread(image_path)

    if image is not None:
        # Convert the Pillow image to a NumPy array
        image_array = np.array(image)

        # Find the coordinates of the brightest pixel
        brightest_pixel_coords = np.unravel_index(np.argmax(image_array), image_array.shape)

        # Get the brightness value of the brightest pixel
        brightest_value = image_array[brightest_pixel_coords]

        # Create an RGB color from the brightness value
        brightest_rgb = (brightest_value/3, brightest_value/3, brightest_value/3)

        # Step 1: Convert anything higher than the value set in variables.py to [255, 255, 255]
        image = np.where(image > brightest_rgb, [255, 255, 255], image)

        # Step 2: Convert anything that is not [255, 255, 255] to [0, 0, 0]
        image = np.where((image != [255, 255, 255]).any(axis=2)[:, :, np.newaxis], [0, 0, 0], image)

        # Save the result
        cv2.imwrite(f"{var.folder}{var.prefix}{file}", image)
    else:
        print(f"Failed to load image: {image_path}")

def load():
    # Load the images
    files = os.listdir(var.folder)
    for file in files:
        if file.endswith(var.format):
            image_path = os.path.join(var.folder, file)
            main(image_path, file)
        else:
            pass

load()