# Camera control code
# getSnapshot.py
# 10/20/2023
# Adapted from https://github.com/pixelink-support/pixelinkPythonWrapper/blob/master/samples/Windows/getSnapshot.py

"""
getSnapshot.py

Sample code to capture an image from a Pixelink camera and save the encoded image to folder as a file.
"""

from pixelinkWrapper import*
from ctypes import*
import os
import variables as var

SUCCESS = 0
FAILURE = 1

"""
Get a snapshot from the camera, and save to a file.
"""
def get_snapshot(hCamera, imageFormat, fileName):

    assert 0 != hCamera
    assert fileName
    
    # Determine the size of buffer we'll need to hold an image from the camera
    rawImageSize = determine_raw_image_size(hCamera)
    if 0 == rawImageSize:
        return FAILURE

    # Create a buffer to hold the raw image
    rawImage = create_string_buffer(rawImageSize)

    if 0 != len(rawImage):
        # Capture a raw image. The raw image buffer will contain image data on success. 
        ret = get_raw_image(hCamera, rawImage)
        if PxLApi.apiSuccess(ret[0]):
            frameDescriptor = ret[1]
            
            assert 0 != len(rawImage)
            assert frameDescriptor
            #
            # Do any image processing here
            #
            
            # Encode the raw image into something displayable
            ret = PxLApi.formatImage(rawImage, frameDescriptor, imageFormat)
            if SUCCESS == ret[0]:
                formatedImage = ret[1]
                # Save formated image into a file
                if save_image_to_file(fileName, formatedImage) == SUCCESS:
                    return SUCCESS
            
    return FAILURE

"""
Query the camera for region of interest (ROI), decimation, and pixel format
Using this information, we can calculate the size of a raw image

Returns 0 on failure
"""
def determine_raw_image_size(hCamera):

    assert 0 != hCamera

    # Get region of interest (ROI)
    ret = PxLApi.getFeature(hCamera, PxLApi.FeatureId.ROI)
    params = ret[2]
    roiWidth = params[PxLApi.RoiParams.WIDTH]
    roiHeight = params[PxLApi.RoiParams.HEIGHT]

    # Query pixel addressing
        # assume no pixel addressing (in case it is not supported)
    pixelAddressingValueX = 1
    pixelAddressingValueY = 1

    ret = PxLApi.getFeature(hCamera, PxLApi.FeatureId.PIXEL_ADDRESSING)
    if PxLApi.apiSuccess(ret[0]):
        params = ret[2]
        if PxLApi.PixelAddressingParams.NUM_PARAMS == len(params):
            # Camera supports symmetric and asymmetric pixel addressing
            pixelAddressingValueX = params[PxLApi.PixelAddressingParams.X_VALUE]
            pixelAddressingValueY = params[PxLApi.PixelAddressingParams.Y_VALUE]
        else:
            # Camera supports only symmetric pixel addressing
            pixelAddressingValueX = params[PxLApi.PixelAddressingParams.VALUE]
            pixelAddressingValueY = params[PxLApi.PixelAddressingParams.VALUE]

    # We can calulate the number of pixels now.
    numPixels = (roiWidth / pixelAddressingValueX) * (roiHeight / pixelAddressingValueY)
    ret = PxLApi.getFeature(hCamera, PxLApi.FeatureId.PIXEL_FORMAT)

    # Knowing pixel format means we can determine how many bytes per pixel.
    params = ret[2]
    pixelFormat = int(params[0])

    # And now the size of the frame
    pixelSize = PxLApi.getBytesPerPixel(pixelFormat)

    return int(numPixels * pixelSize)

"""
Capture an image from the camera.
 
NOTE: PxLApi.getNextFrame is a blocking call. 
i.e. PxLApi.getNextFrame won't return until an image is captured.
So, if you're using hardware triggering, it won't return until the camera is triggered.

Returns a return code with success and frame descriptor information or API error
"""
def get_raw_image(hCamera, rawImage):

    assert 0 != hCamera
    assert 0 != len(rawImage)

    MAX_NUM_TRIES = 4
      
    # Get an image
    # NOTE: PxLApi.getNextFrame can return ApiCameraTimeoutError on occasion.
    # How you handle this depends on your situation and how you use your camera. 
    # For this sample app, we'll just retry a few times.
    ret = (PxLApi.ReturnCode.ApiUnknownError,)

    for i in range(MAX_NUM_TRIES):
        ret = PxLApi.getNextFrame(hCamera, rawImage)
        if PxLApi.apiSuccess(ret[0]):
            break

    # Done capturing, so no longer need the camera streaming images.
    # Note: If ret is used for this call, it will lose frame descriptor information.

    return ret

"""
Save the encoded image buffer to a file
This overwrites any existing file

Returns SUCCESS or FAILURE
"""
def save_image_to_file(fileName, formatedImage):
    
    assert fileName
    assert 0 != len(formatedImage)

    folder = var.folder
    if not os.path.exists(folder):
        os.makedirs(folder)
        print("Folder '" + folder + "'does not exist. Creating folder '" + folder + "'.")
    filepath = folder + fileName
    # Open a file for binary write
    file = open(filepath, "wb")
    if None == file:
        return FAILURE
    numBytesWritten = file.write(formatedImage)
    file.close()

    if numBytesWritten == len(formatedImage):
        return SUCCESS

    return FAILURE


def main(number):

    # Tell the camera we want to start using it.
	# NOTE: We're assuming there's only one camera.
    ret = PxLApi.initialize(var.camera)
    if not PxLApi.apiSuccess(ret[0]):
        return 1
    hCamera = ret[1]

    folder = var.folder
    number_done = 0

    while number_done < number:
        ret = PxLApi.setStreamState(hCamera, PxLApi.StreamState.START)
        if not PxLApi.apiSuccess(ret[0]):
            return FAILURE
        number_done += 1
        filename = var.filename + str(number_done).rjust(3, '0') + "." + var.format.strip().lower()
        number_done -= 1
        # Get a snapshot and save it to a folder as a file
        retVal = get_snapshot(hCamera, var.pxlformat, filename)
        if SUCCESS == retVal:
            number_done += 1
            print("Saved image to '%s%s'" % (folder, filename))
        if SUCCESS != retVal:
            print("ERROR: Unable to capture an image")
            return FAILURE

    # Tell the camera we're done with it.
    PxLApi.setStreamState(hCamera, PxLApi.StreamState.STOP)
    PxLApi.uninitialize(hCamera)

def stack(number, stack):

    # Tell the camera we want to start using it.
	# NOTE: We're assuming there's only one camera.
    ret = PxLApi.initialize(var.camera)
    if not PxLApi.apiSuccess(ret[0]):
        return 1
    hCamera = ret[1]

    folder = var.folder
    number_done = 0
    stack_number_done = 0

    while number_done < number:
        while stack_number_done < stack:
            ret = PxLApi.setStreamState(hCamera, PxLApi.StreamState.START)
            if not PxLApi.apiSuccess(ret[0]):
                return FAILURE
            filename = var.filename + str(number_done + 1).rjust(3, '0') + "_" + str(stack_number_done + 1).rjust(3, '0') + "." + var.format.strip().lower()
            # Get a snapshot and save it to a folder as a file
            retVal = get_snapshot(hCamera, var.pxlformat, filename)
            if SUCCESS == retVal:
                stack_number_done += 1
                print("Saved image to '%s%s'" % (folder, filename))
            if SUCCESS != retVal:
                print("ERROR: Unable to capture an image")
                return FAILURE
        if var.stack_folders == True:
            directory_path = var.folder + var.filename + str(number_done + 1).rjust(3, '0')
            files = os.listdir(var.folder)
            # Check if the directory exists, and create it if it doesn't
            if not os.path.exists(directory_path):
                os.makedirs(directory_path)
                print(f"Directory '{directory_path}' created.")
            else:
                print(f"Directory '{directory_path}' already exists.")
            for file in files:
                if file.endswith(var.format):
                    os.rename(os.path.join(var.folder, file), os.path.join(directory_path, file))
                else:
                    pass
        else:
            pass
        stack_number_done = 0
        number_done += 1
    # Tell the camera we're done with it.
    PxLApi.setStreamState(hCamera, PxLApi.StreamState.STOP)
    PxLApi.uninitialize(hCamera)
