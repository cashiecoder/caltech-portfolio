import cv2
import variables as var
import os

filename = var.folder + var.filename + "001_stacked." + var.format
# Load the subject image (the image with the subject you want)
artifact_image = cv2.imread(filename)

# Load the artifact image (the image with the artifacts you want to remove)
subject_image = cv2.imread("./collimator_20231023_0/dark.jpeg")

# Ensure that the images have the same dimensions
if subject_image.shape == artifact_image.shape:
    if not os.path.exists(var.subtracted):
        os.makedirs(var.subtracted)
    # Subtract the artifact image from the subject image
    result = cv2.subtract(artifact_image, subject_image)
    foldername = var.folder[2:-1]
    new_filename = var.subtracted + "subtracted_" + foldername + "." + var.format
    # Save the result to a file
    cv2.imwrite(new_filename, result)

else:
    print("Images have different dimensions and cannot be subtracted.")
