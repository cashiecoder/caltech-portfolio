f = 0.6
# s_obj = 11850.54
# s_img = (f * s_obj)/(s_obj - f)
def find_s_img(s_obj):
    s_img = (f * s_obj)/(s_obj - f)
    print("The distance for the focus is " + str(s_img))

def find_s_img_10(s_obj):
    s_obj -= 10
    s_img = (f * s_obj)/(s_obj - f)
    print("If it was 10m closer it would be " + str(s_img))

def diff(s_obj):
    s_img1 = (f * s_obj)/(s_obj - f)
    s_obj -= 10
    s_img2 = (f * s_obj)/(s_obj - f)
    print("The difference between them is " + str((s_img2 - s_img1)))

find_s_img(11850.54)

find_s_img_10(11850.54)

diff(11850.54)