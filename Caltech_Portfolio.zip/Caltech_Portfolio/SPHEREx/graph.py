import csv
from matplotlib import pyplot as plt
from math import pi, sqrt

filename = 'file.csv'
with open(filename) as f:
    reader = csv.reader(f)
    header_row = next(reader)

    numbers, pixels = [], []
    for row in reader:
        number = float(row[0])  # Convert the first column to an integer
        numbers.append(number)
        pixel = int(row[1])    # Convert the second column to an integer
        pixels.append(pixel)
    
diameter = []
for pixel in pixels:
    radius_squared = pixel/pi
    radius = sqrt(radius_squared)
    diametervar = radius * 2 * 100
    diameter.append(diametervar)

# Plot data
fig = plt.figure(dpi=128, figsize=(10, 6))
plt.plot(numbers, pixels, c='red', label="Area")
plt.plot(numbers, diameter, c='Blue', label="Diameter (1000x magnification)")

# Format plot
plt.title("Number of white pixels", fontsize=24)
plt.xlabel("Focus (in mm)", fontsize=16)
plt.ylabel("Pixels", fontsize=16)
plt.tick_params(axis='both', which='major', labelsize=16)
plt.legend(loc='upper right')

plt.show()
