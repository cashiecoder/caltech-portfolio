# Camera control code
# routine.py
# 10/20/2023

import capture
import to_bw as tbw
import image_info
import os
import stack
import variables as var
import shutil

files = os.listdir("./")
if "capture.py" and "getSnapshot.py" and "image_info.py" and "to_bw.py" and "variables.py" in files:
    pass
else:
    print('Please make sure "capture.py", "getSnapshot.py", "image_info.py", "to_bw.py", and "variables.py" are in the current working directory.')

def main():
    input("Press return to when ready to take pictures.")
    if var.stack == True:
        capture.main()
        stack.main()
        print("Stacking images.")
    else:
        capture.main()
    """print("Converting images to B/W.")
    tbw.load()
    image_info.load()
    if var.organize == True:
        files = os.listdir(var.folder)
        for file in files:
            if file.startswith(var.prefix):
                directory_path = var.folder + var.prefix + var.stacked_image_folder
                if not os.path.exists(directory_path):
                    os.makedirs(directory_path)
                else:
                    pass
                src_path = os.path.join(var.folder, file)
                dst_path = os.path.join(directory_path, file)
                shutil.move(src_path, dst_path)

        files = os.listdir(var.folder)
        for file in files:
            directory_path = var.folder + var.stacked_image_folder
            if not os.path.exists(directory_path):
                os.makedirs(directory_path)
            else:
                pass
            if file.endswith(var.format):
                src_path = os.path.join(var.folder, file)
                dst_path = os.path.join(directory_path, file)
                shutil.move(src_path, dst_path)
            else:
                pass
        
        move = input("Would you like to move the results of this into a subfolder (y/n)?").lower()
        if move == "y" or "yes":
            new_folder = input("What would you like the folder to be called?")
            pack = []
            files = os.listdir(var.folder)
            for file in files:
                if var.filename in file:
                    pack.append(file)
                elif var.stacked_image_folder in file:
                    pack.append(file)
            for file in pack:
                new_location = var.folder + new_folder + file
                shutil.move(file, new_location)
    else:
        pass"""

main()
