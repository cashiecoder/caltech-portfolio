# Camera control code
# Pictures.py
# 10/20/2023

import variables as var
import getSnapshot as gs
import os

# Initialization
if os.path.isfile("getSnapshot.py") and os.path.isfile("variables.py"):
    pass
else:
    print("You do not have the required files. Check to make sure that getSnapshot.py and variables.py exist in the working folder.")

number = var.num
gs.main(number)
