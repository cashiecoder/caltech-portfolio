# Camera control code
# image_info.py
# 10/20/2023

from PIL import Image
import os
import variables as var
import csv

def info(filename, index):
    # Open the image
    image = Image.open(filename)

    # Convert the image to grayscale
    image = image.convert("L")

    # Convert the grayscale image to a NumPy array for faster processing
    import numpy as np
    image_array = np.array(image)

    # Count the number of black (0) and white (255) pixels
    white_pixels = np.sum(image_array == 255)
    with open('file.csv', 'a') as f:
        f.write('%s,%s\n' % (index, white_pixels))
    

def load():
    # Load the images
    files = os.listdir(var.bw)
    files.sort()
    sorted_files = sorted(files, key=lambda x: int(x.split('_')[-1].split('.')[0]))
    for index, file in enumerate(sorted_files):
        if file.endswith(var.format) and file.startswith(var.prefix):
            image_path = os.path.join(var.bw, file)
            info(image_path, index+1)
        else:
            pass

load()