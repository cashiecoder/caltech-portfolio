#!/usr/bin/env python3
"""
Dish thermistor heatmap — full rewrite with fixed colorbar + slider + play

Usage examples:
    python dish_thermistor_heatmap.py --folder ./data --labels --dots shade
    python dish_thermistor_heatmap.py --folder ./data --csv out_csvs --save first_frame.png

Notes:
 - Default interpolation method is "tri".
 - Global color range (vmin/vmax) comes from the frame with the largest (max-min) temperature range.
 - The colorbar uses a fixed axes so the main plot won't shift or shrink during playback.
"""

import os
import re
import glob
import json
import math
import time
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation
from matplotlib.widgets import Slider, Button

# ---------------- Thermistor constants ----------------
R_SERIES = 32400.0
BETA = 3892.0
R_0 = 10000.0
T0_K = 25.0 + 273.15
MAX_R = 200_000
MIN_V = 0.1

# ---------------- Regex / helpers ----------------
ANT_PATTERN = re.compile(r'^(p(\d+)([rc])_(orange|green))$')
TS_PATTERN = re.compile(r'(\d{8}_\d{6})')

def extract_timestamp_from_name(fname):
    m = TS_PATTERN.search(os.path.basename(fname))
    return m.group(1) if m else None

def sort_key_by_timestamp_or_mtime(path):
    ts = extract_timestamp_from_name(path)
    if ts:
        try:
            return time.strptime(ts, "%Y%m%d_%H%M%S")
        except Exception:
            pass
    return os.path.getmtime(path)

# ---------------- Thermistor math ----------------
def calc_R_th_from_voltage(V_t, V_0, V_5, R_series_local=R_SERIES):
    if V_0 is None or V_5 is None:
        return None
    Vs_local = V_5 - V_0
    V_local = V_t - V_0
    if Vs_local <= 0 or V_local <= 0 or V_local >= Vs_local or math.isclose(Vs_local - V_local, 0.0):
        return None
    try:
        R_th = (V_local * R_series_local) / (Vs_local - V_local)
    except Exception:
        return None
    if not math.isfinite(R_th) or R_th <= 0 or R_th > MAX_R:
        return None
    return R_th

def temp_from_resistance_C(R, r0=R_0, beta_val=BETA, t0_k=T0_K):
    if R is None or R <= 0:
        return None
    try:
        ln_term = math.log(R / r0)
        invT = (1.0 / t0_k) + (1.0 / beta_val) * ln_term
        if invT <= 0:
            return None
        T_k = 1.0 / invT
        return T_k - 273.15
    except Exception:
        return None

# ---------------- File IO / parsing ----------------
def get_all_json_files(folder):
    pattern = os.path.join(folder, "*.json")
    files = glob.glob(pattern)
    if not files:
        raise FileNotFoundError(f"No JSON files found in {folder}")
    files.sort(key=sort_key_by_timestamp_or_mtime)
    return files

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

def extract_readings(data):
    readings = []
    for section, entries in data.items():
        for _, info in entries.items():
            antenna = info.get("antenna")
            if antenna is None:
                continue
            m = ANT_PATTERN.match(antenna)
            if not m:
                continue
            pnum = int(m.group(2))
            rc = m.group(3)
            color = m.group(4)
            readings.append({
                "antenna": antenna,
                "pnum": pnum,
                "rc": rc,
                "color": color,
                "voltage": info.get("voltage"),
                "terminal": info.get("terminal"),
                "cable": info.get("cable")
            })
    return readings

# ---------------- Geometry ----------------
def compute_positions(readings, dish_diameter_m=5.0):
    r_dish = dish_diameter_m / 2.0
    inch_m = 0.0254
    sector_width = math.radians(45.0)
    half_sector = sector_width / 2.0

    r_rim_base = max(0.05, r_dish - inch_m)
    r_prange = r_rim_base
    r_pc_orange = max(0.05, r_rim_base - 0.9144)
    r_pc_green  = max(0.05, 0.92)

    pts = []
    for rd in readings:
        pnum = rd["pnum"]
        rc = rd["rc"]
        color = rd["color"]
        V_t = rd["voltage"]

        sector_start = (math.pi / 2.0) - ((pnum - 1) * sector_width)

        if rc == 'r':
            if color == 'green':
                ang = sector_start
                r = r_prange
            else:
                ang = sector_start - half_sector
                r = r_prange
        else:
            if color == 'green':
                ang = sector_start
                r = r_pc_green
            else:
                ang = sector_start - half_sector
                r = r_pc_orange

        x = r * math.cos(ang)
        y = r * math.sin(ang)

        pts.append({**rd, "r_m": r, "angle_rad": ang, "x_m": x, "y_m": y, "V_t": V_t})
    return pts

# ---------------- Frame processing ----------------
def process_file(path, dish_diameter_m):
    data = load_json(path)

    # pick up reference voltages (same logic)
    ain0 = ain2 = ain1 = ain3 = None
    for section, entries in data.items():
        for _, info in entries.items():
            term = (info.get("terminal") or "").lower()
            if term == "ain0":
                ain0 = info.get("voltage")
            elif term == "ain2":
                ain2 = info.get("voltage")
            elif term == "ain1":
                ain1 = info.get("voltage")
            elif term == "ain3":
                ain3 = info.get("voltage")
    v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
    V_0 = (sum(v0_list) / len(v0_list)) if v0_list else None
    v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
    V5_raw = (sum(v5_list) / len(v5_list)) if v5_list else None
    V_5 = (V5_raw * 2.0) if (V5_raw is not None) else None

    readings = extract_readings(data)
    pts = compute_positions(readings, dish_diameter_m=dish_diameter_m)

    for p in pts:
        Vt = p.get("voltage")
        R_th = None
        T_C = None
        if isinstance(Vt, (int, float)) and Vt > MIN_V and V_0 is not None and V_5 is not None:
            R_th = calc_R_th_from_voltage(Vt, V_0, V_5)
            if R_th is not None:
                T_C = temp_from_resistance_C(R_th)
        p["R_th"] = R_th
        p["T_C"] = T_C

    df = pd.DataFrame(pts).sort_values(["pnum", "rc", "color"])
    ts = extract_timestamp_from_name(path) or os.path.basename(path)
    return {"file": path, "timestamp": ts, "pts": pts, "df": df}

def build_master_layout(frames):
    # unique antennas -> positions
    ant_map = {}
    for f in frames:
        for p in f["pts"]:
            ant = p["antenna"]
            if ant not in ant_map:
                ant_map[ant] = (p["x_m"], p["y_m"], p["pnum"], p["rc"], p["color"])
    # stable sort: pnum, rc, color, antenna
    def key(item):
        ant, (x,y,pnum,rc,color) = item
        return (pnum, rc, color, ant)
    items = sorted(ant_map.items(), key=key)
    antennas = [it[0] for it in items]
    xs = np.array([it[1][0] for it in items], dtype=float)
    ys = np.array([it[1][1] for it in items], dtype=float)
    return antennas, xs, ys

def frames_to_zarrays(frames, antennas):
    arrs = []
    for f in frames:
        amap = {p["antenna"]: p.get("T_C") for p in f["pts"]}
        z = np.array([amap.get(a, np.nan) for a in antennas], dtype=float)
        arrs.append(z)
    return arrs

# ---------------- Plot helpers (tri) ----------------
def make_tri(xs, ys):
    return Triangulation(xs, ys)

def mask_triangles_for_nan(tri, z):
    # mask triangles that reference any NaN vertex
    tri_mask = np.any(np.isnan(z)[tri.triangles], axis=1)
    tri.set_mask(tri_mask)

# ---------------- Main interactive slideshow ----------------
def make_slideshow(folder, method="tri", dish_diameter_m=5.0, show_labels=False,
                   dot_style=None, csv_folder=None, save_path=None, interval_ms=800):
    # collect files
    if os.path.isdir(folder):
        files = get_all_json_files(folder)
    elif os.path.isfile(folder):
        files = [folder]
    else:
        raise FileNotFoundError(f"{folder} not found")

    if not files:
        raise RuntimeError("No files to process")

    # process frames
    frames = []
    for f in files:
        try:
            frames.append(process_file(f, dish_diameter_m))
        except Exception as e:
            print(f"Failed to process {f}: {e}")
    if not frames:
        raise RuntimeError("No valid frames produced")

    antennas, xs, ys = build_master_layout(frames)
    if len(xs) < 3:
        raise RuntimeError("Need at least 3 distinct sensor positions for triangulation")

    zs_per_frame = frames_to_zarrays(frames, antennas)

    # determine global vmin/vmax from frame with largest range (max-min)
    max_ranges = []
    for z in zs_per_frame:
        valid = z[np.isfinite(z)]
        if valid.size == 0:
            max_ranges.append((np.nan, np.nan, 0.0))
        else:
            max_ranges.append((np.nanmin(valid), np.nanmax(valid), float(np.nanmax(valid) - np.nanmin(valid))))
    rngs = np.array([r[2] for r in max_ranges], dtype=float)
    if np.all(np.isnan(rngs)) or np.nanmax(rngs) == 0.0:
        vmin = None
        vmax = None
        print("Warning: no valid temps or no variation. Colorbar disabled.")
    else:
        idx = int(np.nanargmax(rngs))
        vmin = float(max_ranges[idx][0])
        vmax = float(max_ranges[idx][1])
        print(f"Using global vmin/vmax from {frames[idx]['file']}: vmin={vmin:.3f}, vmax={vmax:.3f}")

    # prepare triangulation
    tri = make_tri(xs, ys)

    # plot setup
    dish_r = dish_diameter_m / 2.0
    title_base = f"Dish thermistor heatmap — diameter {dish_diameter_m:.2f} m"

    fig = plt.figure(figsize=(9,9))
    # main axis
    main_ax = fig.add_axes([0.06, 0.08, 0.86, 0.86])  # leave space at right for fixed colorbar axis
    main_ax.set_aspect('equal', 'box')

    # fixed colorbar axis on the right (so adding/removing does not change main_ax)
    cax = fig.add_axes([0.94, 0.12, 0.03, 0.75])

    # initial frame index
    idx = 0

    # function to draw a frame and return the contour (QuadContourSet) or PolyCollection
    current_contour = None
    def draw_frame(ax, tri, zvals, timestamp, title):
        nonlocal current_contour
        # remove old contour collections from ax
        if current_contour is not None:
            # current_contour may be a ContourSet: remove its artists
            try:
                for coll in getattr(current_contour, "collections", []):
                    coll.remove()
            except Exception:
                pass
            current_contour = None

        # mask triangles referencing NaNs
        mask_triangles_for_nan(tri, zvals)

        if np.all(np.isnan(zvals)):
            ax.clear()
            ax.text(0, 0, "No valid temperature data for this frame", ha='center', va='center')
            ax.set_xlim(-dish_r*1.05, dish_r*1.05)
            ax.set_ylim(-dish_r*1.05, dish_r*1.05)
            ax.set_title(title + "\n" + timestamp)
            return None

        # tricontourf (triangulation) — returns QuadContourSet
        contour = ax.tricontourf(tri, zvals, levels=100, cmap="coolwarm", vmin=vmin, vmax=vmax)
        current_contour = contour

        # circle
        circ = plt.Circle((0,0), dish_r, color='k', fill=False, linewidth=1.2)
        ax.add_patch(circ)

        # dots
        if dot_style:
            if dot_style == "black":
                ax.scatter(xs, ys, c='k', s=48, edgecolor='k', zorder=10)
            elif dot_style == "shade":
                ax.scatter(xs, ys, c=zvals, cmap="coolwarm", vmin=vmin, vmax=vmax, s=48, edgecolor='k', zorder=10)

        if show_labels:
            for xi, yi, ant in zip(xs, ys, antennas):
                ax.text(xi, yi, ant, fontsize=8, ha='center', va='center', zorder=11)

        ax.set_xlim(-dish_r*1.05, dish_r*1.05)
        ax.set_ylim(-dish_r*1.05, dish_r*1.05)
        ax.set_title(title + "\n" + timestamp)
        return contour

    # draw initial frame
    initial_contour = draw_frame(main_ax, tri, zs_per_frame[idx], frames[idx]["timestamp"], title_base)

    # create single colorbar (if we have a contour)
    colorbar = None
    if initial_contour is not None:
        colorbar = fig.colorbar(initial_contour, cax=cax)
        colorbar.set_label("Temperature (°C)")
    else:
        # clear cax to keep it empty
        cax.clear()

    # slider + buttons axes
    ax_slider = fig.add_axes([0.12, 0.02, 0.6, 0.03])
    slider = Slider(ax_slider, 'Frame', 0, len(frames)-1, valinit=0, valstep=1)

    ax_play = fig.add_axes([0.75, 0.02, 0.08, 0.04])
    btn_play = Button(ax_play, 'Play')

    ax_prev = fig.add_axes([0.85, 0.02, 0.06, 0.04])
    btn_prev = Button(ax_prev, 'Prev')

    ax_next = fig.add_axes([0.92, 0.02, 0.06, 0.04])
    btn_next = Button(ax_next, 'Next')

    playing = {"state": False}
    timer = fig.canvas.new_timer(interval=interval_ms)

    def update_to(frame_index, update_slider=True):
        nonlocal colorbar
        frame_index = int(frame_index)
        # redraw frame on main_ax
        contour = draw_frame(main_ax, tri, zs_per_frame[frame_index], frames[frame_index]["timestamp"], title_base)

        # update colorbar in the fixed cax (remove old colorbar artists first)
        if colorbar is not None:
            # remove old colorbar artists from cax
            try:
                colorbar.remove()
            except Exception:
                pass
            colorbar = None

        if contour is not None:
            colorbar = fig.colorbar(contour, cax=cax)
            colorbar.set_label("Temperature (°C)")
        else:
            cax.clear()

        if update_slider:
            slider.set_val(frame_index)
        fig.canvas.draw_idle()

    def slider_changed(val):
        update_to(int(val), update_slider=False)

    slider.on_changed(slider_changed)

    def timer_step():
        nonlocal idx
        idx = (idx + 1) % len(frames)
        update_to(idx)

    def btn_play_clicked(event):
        playing["state"] = not playing["state"]
        btn_play.label.set_text("Pause" if playing["state"] else "Play")
        if playing["state"]:
            # start repeated timer
            timer.add_callback(timer_step)
            timer.start()
        else:
            try:
                timer.stop()
            except Exception:
                pass

    def btn_prev_clicked(event):
        nonlocal idx
        idx = (idx - 1) % len(frames)
        update_to(idx)

    def btn_next_clicked(event):
        nonlocal idx
        idx = (idx + 1) % len(frames)
        update_to(idx)

    btn_play.on_clicked(btn_play_clicked)
    btn_prev.on_clicked(btn_prev_clicked)
    btn_next.on_clicked(btn_next_clicked)

    # optional: write per-frame CSVs
    if csv_folder:
        os.makedirs(csv_folder, exist_ok=True)
        for f in frames:
            df = f["df"]
            if not df.empty:
                base = os.path.basename(f["file"])
                ts = f["timestamp"]
                safe = re.sub(r'[^A-Za-z0-9_.-]', '_', base)
                outp = os.path.join(csv_folder, f"{safe}_{ts}.csv")
                df.to_csv(outp, index=False)
        print(f"Wrote per-frame CSVs to {csv_folder}")

    # optional: save initial frame image
    if save_path:
        fig.savefig(save_path, dpi=200)
        print(f"Saved image to {save_path}")

    plt.show()

# ---------------- CLI ----------------
def main():
    p = argparse.ArgumentParser(description="Dish thermistor heatmap slideshow (tri default).")
    p.add_argument("--folder", "-f", help="Folder containing JSON files")
    p.add_argument("--file", "-F", help="Single JSON file (instead of folder)")
    p.add_argument("--save", "-s", help="Save initial frame as image (png/pdf)")
    p.add_argument("--csv", help="Folder to write per-frame CSVs")
    p.add_argument("--dish-diameter", type=float, default=5.0, help="Dish diameter in meters")
    p.add_argument("--method", choices=["tri", "polar"], default="tri", help="Interpolation method (tri default)")
    p.add_argument("--labels", action="store_true", help="Show sensor labels")
    p.add_argument("--dots", choices=["black", "shade", "off"], default="off", help="Dot style")
    p.add_argument("--interval", type=int, default=800, help="Play interval in ms")
    args = p.parse_args()

    src = None
    if args.file:
        src = args.file
    elif args.folder:
        src = args.folder
    else:
        p.error("You must provide --folder or --file")

    dot_style = None
    if args.dots == "black":
        dot_style = "black"
    elif args.dots == "shade":
        dot_style = "shade"

    try:
        make_slideshow(src, method=args.method, dish_diameter_m=args.dish_diameter,
                       show_labels=args.labels, dot_style=dot_style,
                       csv_folder=args.csv, save_path=args.save, interval_ms=args.interval)
    except Exception as e:
        print("Error:", e)
        raise

if __name__ == "__main__":
    main()
