#!/usr/bin/env python3
"""
RibViewer - PyQt6 viewer that:
- loads the latest ssh_test_*.json from FOLDER
- computes thermistor R and temperature (C) for p1..p8 blue/green rim/center sensors
- shows a table and three matplotlib charts (rim, center, delta)
- allows CSV export and highlights temps above TEMP_THRESHOLD
"""

import sys
import os
import json
import math
from pathlib import Path
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QVBoxLayout,
    QPushButton, QFileDialog, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QSizePolicy, QMessageBox, QTabWidget
)
from PyQt6.QtCore import Qt

# Matplotlib Qt canvas
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt
import pandas as pd

# ----------------- Config / Constants -----------------
FOLDER = r"C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\thermistor_data"
FILEPATH = None

R_SERIES = 32400.0
BETA = 3892.0
R_0 = 10000.0
t_0 = 25.0 + 273.15
MAX_R = 200_000
MIN_V = 0.1

TEMP_THRESHOLD = 45.0  # highlight cells above this temperature (°C)

# ----------------- Helpers -----------------
def calc_R_th_from_voltage(V_t, V_0, V_5, R_series_local=R_SERIES):
    """
    Robust calculation of thermistor resistance from measured voltages.

    Requirements / guards:
      - V_0 and V_5 must be present
      - V_t must be a numeric and greater than MIN_V
      - V_local = V_t - V_0 must be > 0 and < Vs_local
      - result must be finite and within (0, MAX_R]
    """
    # basic presence/type checks
    if V_0 is None or V_5 is None or V_t is None:
        return None
    if not isinstance(V_t, (int, float)) or not isinstance(V_0, (int, float)) or not isinstance(V_5, (int, float)):
        return None

    # ignore tiny/noisy voltages
    if V_t <= MIN_V:
        return None

    Vs_local = V_5 - V_0
    V_local = V_t - V_0

    # sanity guards
    if not math.isfinite(Vs_local) or not math.isfinite(V_local):
        return None
    if Vs_local <= 0 or V_local <= 0 or V_local >= Vs_local or math.isclose(Vs_local - V_local, 0.0, rel_tol=1e-12, abs_tol=1e-12):
        return None

    try:
        R_th = (V_local * R_series_local) / (Vs_local - V_local)
    except Exception:
        return None

    if not math.isfinite(R_th) or R_th <= 0 or R_th > MAX_R:
        return None

    return R_th

def temp_from_resistance_C(R, r0=R_0, beta_val=BETA, t0_k=t_0):
    """
    Convert thermistor resistance to temperature (°C) using the Beta equation:
      1/T = 1/T0 + (1/β) * ln(R/R0)

    Returns None for invalid inputs or non-physical results.
    """
    if R is None or not isinstance(R, (int, float)) or R <= 0:
        return None

    try:
        ratio = R / r0
        if ratio <= 0 or not math.isfinite(ratio):
            return None
        ln_term = math.log(ratio)

        invT = (1.0 / t0_k) + (ln_term / beta_val)
        if not math.isfinite(invT) or invT <= 0:
            return None

        T_k = 1.0 / invT
        T_c = T_k - 273.15

        # sanity limits to avoid ridiculous numbers (tunable)
        if not math.isfinite(T_c) or T_c < -50 or T_c > 250:
            return None

        return T_c
    except Exception:
        return None

# ----------------- File and Data -----------------
def get_latest_file(folder=FOLDER):
    try:
        files = [f for f in os.listdir(folder) if f.startswith("ssh_test_") and f.endswith(".json")]
    except FileNotFoundError:
        files = []
    if not files:
        return None
    # sort by filename; if filenames include timestamp, reverse gives latest-first
    files.sort(reverse=True)
    return os.path.join(folder, files[0])

def load_data_from_file(path):
    with open(path, "r") as f:
        return json.load(f)

# ----------------- Data processing -----------------
def compute_panel_temperatures(data):
    """
    Returns a pandas DataFrame indexed by P1..P8 with columns:
    rim_blue_C, rim_green_C, rim_delta,
    ctr_blue_C, ctr_green_C, ctr_delta

    V_0 and V_5 are derived from terminal readings:
      - V_0 = mean(ain0, ain2) if present
      - V5_raw = mean(ain1, ain3) if present
      - V_5 = V5_raw * 2.0 (to match make_heatmap behavior)
    """
    # ------------------ derive V_0 and V_5 from terminal voltages (match heatmap script) ------------------
    ain0 = ain2 = ain1 = ain3 = None
    for section, entries in data.items():
        for _, info in entries.items():
            term = str(info.get("terminal", "")).lower()
            if term == "ain0":
                v = info.get("voltage")
                if isinstance(v, (int, float)):
                    ain0 = v if ain0 is None else ain0
            elif term == "ain2":
                v = info.get("voltage")
                if isinstance(v, (int, float)):
                    ain2 = v if ain2 is None else ain2
            elif term == "ain1":
                v = info.get("voltage")
                if isinstance(v, (int, float)):
                    ain1 = v if ain1 is None else ain1
            elif term == "ain3":
                v = info.get("voltage")
                if isinstance(v, (int, float)):
                    ain3 = v if ain3 is None else ain3

    v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
    V_0 = (sum(v0_list) / len(v0_list)) if v0_list else None
    v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
    V5_raw = (sum(v5_list) / len(v5_list)) if v5_list else None
    V_5 = (V5_raw * 2.0) if (V5_raw is not None) else None

    # ------------------ prepare result structure ------------------
    p_nums = [f"P{i}" for i in range(1, 9)]
    results = {p: {"rim_blue": None, "rim_green": None, "ctr_blue": None, "ctr_green": None} for p in p_nums}

    # iterate entries and compute temps using the global V_0 / V_5
    for section, entries in data.items():
        for _, info in entries.items():
            ant = info.get("antenna")
            v = info.get("voltage")
            if not ant or not isinstance(v, (int, float)):
                continue
            parts = ant.split("_")
            if len(parts) < 2:
                continue
            base = parts[0]  # e.g. p1r or p1c
            color = parts[1]
            if color not in ("blue", "green"):
                continue
            # require base like p{N}{r|c}
            if not base.startswith("p") or len(base) < 3:
                continue
            try:
                panel_num = int(base[1:-1])  # handles p1r, p10c etc
                pos = base[-1]  # 'r' or 'c'
            except Exception:
                continue
            if panel_num < 1 or panel_num > 8:
                continue
            pkey = f"P{panel_num}"

            # compute temperature using the terminal-derived V_0 / V_5
            Rth = None
            T = None
            if isinstance(v, (int, float)) and v > MIN_V and V_0 is not None and V_5 is not None:
                Rth = calc_R_th_from_voltage(V_t=v, V_0=V_0, V_5=V_5)
                if Rth is not None:
                    T = temp_from_resistance_C(Rth)

            if pos == "r":
                if color == "blue":
                    results[pkey]["rim_blue"] = T
                else:
                    results[pkey]["rim_green"] = T
            elif pos == "c":
                if color == "blue":
                    results[pkey]["ctr_blue"] = T
                else:
                    results[pkey]["ctr_green"] = T

    # Build DataFrame
    rows = []
    for p in p_nums:
        r = results[p]
        rim_b = r["rim_blue"]
        rim_gr = r["rim_green"]
        ctr_b = r["ctr_blue"]
        ctr_gr = r["ctr_green"]
        rim_delta = None if (rim_b is None or rim_gr is None) else (rim_b - rim_gr)
        ctr_delta = None if (ctr_b is None or ctr_gr is None) else (ctr_b - ctr_gr)
        rows.append({
            "panel": p,
            "rim_blue_C": rim_b,
            "rim_green_C": rim_gr,
            "rim_delta": abs(rim_delta) if rim_delta is not None else None,
            "ctr_blue_C": ctr_b,
            "ctr_green_C": ctr_gr,
            "ctr_delta": abs(ctr_delta) if ctr_delta is not None else None
        })
    df = pd.DataFrame(rows).set_index("panel")
    return df

# ----------------- Qt Viewer -----------------
class RibViewer(QWidget):
    def __init__(self):
        super().__init__()

        # Try to load latest file
        global FILEPATH
        FILEPATH = get_latest_file()
        if FILEPATH:
            try:
                data = load_data_from_file(FILEPATH)
                file_label = f"File: {Path(FILEPATH).name}"
            except Exception as e:
                QMessageBox.warning(self, "Load error", f"Failed to load {FILEPATH}: {e}")
                sys.exit(1)
        else:
            QMessageBox.warning(self, "Load error", f"Failed to load {FILEPATH}: {e}")
            sys.exit(1)

        # compute temps DataFrame
        self.df = compute_panel_temperatures(data)

        # Window setup
        title_path = Path(FILEPATH).stem if FILEPATH is not None else "(no file)"
        self.setWindowTitle(f"Antenna Rib Temperature Viewer - {title_path}")
        self.resize(1100, 700)

        main_layout = QVBoxLayout(self)

        # header with filename and export button
        header_h = QHBoxLayout()
        header_h.addWidget(QLabel(file_label))
        header_h.addStretch(1)
        export_btn = QPushButton("Export CSV")
        export_btn.clicked.connect(self.export_csv)
        header_h.addWidget(export_btn)
        refresh_btn = QPushButton("Refresh (reload file)")
        refresh_btn.clicked.connect(self.reload_and_refresh)
        header_h.addWidget(refresh_btn)
        main_layout.addLayout(header_h)

        # Use a horizontal split: left table, right tabs with plots
        content_h = QHBoxLayout()
        left_v = QVBoxLayout()
        left_v.addWidget(QLabel("Panel temperatures (rim / center: blue vs green)"))
        self.table = QTableWidget()
        self.table.setColumnCount(len(self.df.columns))
        self.table.setHorizontalHeaderLabels(self.df.columns.tolist())
        self.table.setRowCount(len(self.df.index))
        self.table.setVerticalHeaderLabels(self.df.index.tolist())
        self.table.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        left_v.addWidget(self.table)
        content_h.addLayout(left_v, 45)

        right_v = QVBoxLayout()
        # tabs for 3 plots
        tabs = QTabWidget()
        # rim tab
        self.rim_canvas = FigureCanvas(plt.Figure(figsize=(6,3)))
        rim_tab = QWidget()
        rim_tab_layout = QVBoxLayout(rim_tab)
        rim_tab_layout.addWidget(NavigationToolbar(self.rim_canvas, self))
        rim_tab_layout.addWidget(self.rim_canvas)
        tabs.addTab(rim_tab, "Rim (blue vs green)")

        # center tab
        self.ctr_canvas = FigureCanvas(plt.Figure(figsize=(6,3)))
        ctr_tab = QWidget()
        ctr_tab_layout = QVBoxLayout(ctr_tab)
        ctr_tab_layout.addWidget(NavigationToolbar(self.ctr_canvas, self))
        ctr_tab_layout.addWidget(self.ctr_canvas)
        tabs.addTab(ctr_tab, "Center (blue vs green)")

        # delta tab
        self.delta_canvas = FigureCanvas(plt.Figure(figsize=(6,3)))
        delta_tab = QWidget()
        delta_tab_layout = QVBoxLayout(delta_tab)
        delta_tab_layout.addWidget(NavigationToolbar(self.delta_canvas, self))
        delta_tab_layout.addWidget(self.delta_canvas)
        # tabs.addTab(delta_tab, "Blue - Green deltas")

        right_v.addWidget(tabs)
        content_h.addLayout(right_v, 55)

        main_layout.addLayout(content_h)

        # Populate table and plots
        self.populate_table()
        self.draw_plots()

    def populate_table(self):
        self.table.clearContents()
        for row_idx, panel in enumerate(self.df.index):
            for col_idx, col in enumerate(self.df.columns):
                val = self.df.loc[panel, col]
                if val is None or (isinstance(val, float) and (math.isnan(val))):
                    txt = ""
                else:
                    txt = f"{val:.2f}"
                item = QTableWidgetItem(txt)
                item.setFlags(item.flags() ^ Qt.ItemFlag.ItemIsEditable)
                # highlight if temperature > threshold (only apply to temp columns, not deltas? we apply to all numeric)
                try:
                    numeric_val = float(val)
                    if col.endswith("_C") and numeric_val >= TEMP_THRESHOLD:
                        # red-ish background
                        item.setBackground(Qt.GlobalColor.red)
                        item.setForeground(Qt.GlobalColor.white)
                except Exception:
                    pass
                self.table.setItem(row_idx, col_idx, item)
        self.table.resizeColumnsToContents()

    def draw_plots(self):
        # Rim plot
        fig = self.rim_canvas.figure
        fig.clear()
        ax = fig.add_subplot(111)
        panels = list(self.df.index)
        x = range(len(panels))
        rim_blue = self.df["rim_blue_C"].tolist()
        rim_green = self.df["rim_green_C"].tolist()
        ax.bar([i-0.2 for i in x], [v if (v is not None and not math.isnan(v)) else 0 for v in rim_blue], width=0.4, label="rim_blue_C")
        ax.bar([i+0.2 for i in x], [v if (v is not None and not math.isnan(v)) else 0 for v in rim_green], width=0.4, label="rim_green_C")
        ax.set_xticks(x)
        ax.set_xticklabels(panels)
        ax.set_ylabel("Temp (°C)")
        ax.set_title("Rim temperatures: blue vs green (P1..P8)")
        ax.legend()
        fig.tight_layout()
        self.rim_canvas.draw()

        # Center plot
        fig = self.ctr_canvas.figure
        fig.clear()
        ax = fig.add_subplot(111)
        ctr_blue = self.df["ctr_blue_C"].tolist()
        ctr_green = self.df["ctr_green_C"].tolist()
        ax.bar([i-0.2 for i in x], [v if (v is not None and not math.isnan(v)) else 0 for v in ctr_blue], width=0.4, label="ctr_blue_C")
        ax.bar([i+0.2 for i in x], [v if (v is not None and not math.isnan(v)) else 0 for v in ctr_green], width=0.4, label="ctr_green_C")
        ax.set_xticks(x)
        ax.set_xticklabels(panels)
        ax.set_ylabel("Temp (°C)")
        ax.set_title("Center temperatures: blue vs green (P1..P8)")
        ax.legend()
        fig.tight_layout()
        self.ctr_canvas.draw()

        # Delta plot
        """
        fig = self.delta_canvas.figure
        fig.clear()
        ax = fig.add_subplot(111)
        rim_delta = self.df["rim_delta"].tolist()
        ctr_delta = self.df["ctr_delta"].tolist()
        ax.bar([i-0.2 for i in x], [v if (v is not None and not math.isnan(v)) else 0 for v in rim_delta], width=0.4, label="rim (blue - green)")
        ax.bar([i+0.2 for i in x], [v if (v is not None and not math.isnan(v)) else 0 for v in ctr_delta], width=0.4, label="ctr (blue - green)")
        ax.set_xticks(x)
        ax.set_xticklabels(panels)
        ax.set_ylabel("Delta Temp (°C)")
        ax.set_title("Blue - Green temperature differences (Rim and Center)")
        ax.axhline(0, color="gray", linewidth=0.8)
        ax.legend()
        fig.tight_layout()
        self.delta_canvas.draw()
        """

    def export_csv(self):
        suggested = f"panel_temps_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        path, _ = QFileDialog.getSaveFileName(self, "Save CSV", suggested, "CSV Files (*.csv)")
        if not path:
            return
        try:
            self.df.to_csv(path)
            QMessageBox.information(self, "Saved", f"CSV saved to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Save failed", f"Failed to save CSV: {e}")

    def reload_and_refresh(self):
        # reload latest file and refresh table/plots
        latest = get_latest_file()
        if not latest:
            QMessageBox.information(self, "No file", "No ssh_test_*.json files found in folder.")
            sys.exit(1)
        else:
            try:
                data = load_data_from_file(latest)
            except Exception as e:
                QMessageBox.warning(self, "Load error", f"Failed to load {latest}: {e}")
                sys.exit(1)
        self.df = compute_panel_temperatures(data)
        self.populate_table()
        self.draw_plots()

# ----------------- main -----------------
def main():
    app = QApplication.instance() or QApplication(sys.argv)
    viewer = RibViewer()
    viewer.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
