import sys
import os
import json
import math
from pathlib import Path
from PyQt6.QtWidgets import QApplication, QWidget, QGridLayout, QLabel, QScrollArea, QVBoxLayout
from PyQt6.QtCore import Qt
from variables.variables import FOLDER

# Folder with JSON files
#FOLDER = r"C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\thermistor_data"
FILEPATH = None

# Constants for thermistor calculations
R_SERIES = 32400.0
BETA = 3892.0
R_0 = 10000.0
t_0 = 25.0 + 273.15
MAX_R = 200_000
MIN_V = 0.1

# Temperature threshold for highlighting
TEMP_THRESHOLD = 45.0

# ----------------- Helpers -----------------
def calc_R_th_from_voltage(V_t, V_0, V_5, R_series_local=R_SERIES):
    if V_0 is None or V_5 is None:
        return None
    Vs_local = V_5 - V_0
    V_local = V_t - V_0
    if Vs_local <= 0 or V_local <= 0 or V_local >= Vs_local or math.isclose(Vs_local - V_local, 0.0):
        return None
    try:
        R_th = (V_local * R_series_local) / (Vs_local - V_local)
    except Exception:
        return None
    if not math.isfinite(R_th) or R_th <= 0 or R_th > MAX_R:
        return None
    return R_th

def temp_from_resistance_C(R, r0=R_0, beta_val=BETA, t0_k=t_0):
    if R is None or R <= 0:
        return None
    try:
        ln_term = math.log(R / r0)
        invT = (1.0 / t0_k) + (1.0 / beta_val) * ln_term
        if invT <= 0:
            return None
        T_k = 1.0 / invT
        return T_k - 273.15
    except Exception:
        return None

# ----------------- File and Data -----------------
def get_latest_file():
    files = [f for f in os.listdir(FOLDER) if f.startswith("ssh_test_") and f.endswith(".json")]
    if not files:
        raise FileNotFoundError("No matching JSON files found.")
    files.sort(reverse=True)
    return os.path.join(FOLDER, files[0])

def load_data():
    global FILEPATH
    FILEPATH = get_latest_file()
    with open(FILEPATH, "r") as f:
        data = json.load(f)
    return data

def group_by_antenna(data):
    groups = {}
    for section, entries in data.items():
        for _, info in entries.items():
            antenna = info.get("antenna")
            if antenna is None:
                continue
            base = "_".join(antenna.split("_")[:-1])  # e.g. p1r, p2c
            if base not in groups:
                groups[base] = {}
            groups[base][antenna.split("_")[-1]] = info
    return groups

# ----------------- Qt Viewer -----------------
class AntennaViewer(QWidget):
    def __init__(self):
        super().__init__()

        data = load_data()

        # safe title (handles FILEPATH None)
        title_path = Path(FILEPATH).stem if FILEPATH is not None else "(no file)"
        self.setWindowTitle(f"Antenna Voltage/Resistance/Temperature Viewer {title_path}")
        self.resize(1000, 600)

        layout = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        grid = QGridLayout(content)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(6)

        grouped = group_by_antenna(data)

        # Column order and colors
        colors = ["orange", "green", "blue", "brown"]
        bg_colors = {
            "orange": "#FFD580",
            "green": "#C6F6C6",
            "blue": "#C6E0F6",
            "brown": "#E0C6A8"
        }
        
        # Highlight colors for temperatures above threshold
        highlight_bg_colors = {
            "orange": "#FFA500",  # Brighter orange
            "green": "#90EE90",   # Brighter green
            "blue": "#87CEFA",    # Brighter blue
            "brown": "#D2B48C"    # Brighter brown
        }

        # Compute V_0 and V_5 from ground refs (if available)
        ain0 = None
        ain2 = None
        ain1 = None
        ain3 = None
        for section, entries in data.items():
            for _, info in entries.items():
                if info.get("terminal", "").lower() == "ain0":
                    ain0 = info.get("voltage")
                if info.get("terminal", "").lower() == "ain2":
                    ain2 = info.get("voltage")
                if info.get("terminal", "").lower() == "ain1":
                    ain1 = info.get("voltage")
                if info.get("terminal", "").lower() == "ain3":
                    ain3 = info.get("voltage")
        v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
        V_0 = (sum(v0_list) / len(v0_list)) if v0_list else None
        v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
        V5_raw = (sum(v5_list) / len(v5_list)) if v5_list else None
        V_5 = (V5_raw * 2.0) if (V5_raw is not None) else None

        # Order groups: p#r then p#c, then air/feed/mount/octbox last
        def sort_key(base):
            if base.startswith("p") and (base.endswith("r") or base.endswith("c")):
                # Extract number and r/c
                num_part = ''.join(ch for ch in base if ch.isdigit())
                rc_part = base[-1]
                num_val = int(num_part) if num_part.isdigit() else 0
                rc_val = 0 if rc_part == "r" else 1  # r first, then c
                return (0, num_val, rc_val)
            if any(base.startswith(x) for x in ("air", "feed", "mount", "octbox")):
                return (2, base)
            return (1, base)

        # 12-unit grid: 4 cols -> span 3 units; 6 cols -> span 2 units
        total_units = 12
        for i in range(total_units):
            grid.setColumnStretch(i, 1)

        row = 0
        for base, antennas in sorted(grouped.items(), key=lambda kv: sort_key(kv[0])):
            header = QLabel(f"<b>{base}</b>")
            header.setAlignment(Qt.AlignmentFlag.AlignCenter)
            header.setStyleSheet("padding:6px;")
            grid.addWidget(header, row, 0, 1, total_units)
            row += 1

            # four antenna boxes, each spans 3 units
            for i, color in enumerate(colors):
                entry = antennas.get(color)
                col_pos = i * 3
                if entry:
                    if entry['antenna'] == "air_orange":
                        voltage = entry.get('voltage')
                        R_val = None
                        T_val = None

                        if isinstance(voltage, (int, float)) and voltage > MIN_V and V_0 is not None and V_5 is not None:
                            R_val = calc_R_th_from_voltage(voltage, V_0, V_5)
                            if R_val:
                                T_val = temp_from_resistance_C(R_val)

                        text = (
                            f"{entry['antenna']}<br>"
                            f"Terminal: {entry['terminal']}<br>"
                            f"Cable: {entry['cable']}<br>"
                            f"Resistor Value: 1k<br>"
                            f"Voltage: {voltage:.4f}"
                            + (f"<br>R: {R_val:.2f} Ω" if R_val else "<br>R: -")
                        )
                        style = f"border: 1px solid gray; padding: 5px; background-color: {bg_colors[color]}; color: black;"

                    elif entry['antenna'] == "air_green":
                        voltage = entry.get('voltage')
                        R_val = None
                        T_val = None

                        if isinstance(voltage, (int, float)) and voltage > MIN_V and V_0 is not None and V_5 is not None:
                            R_val = calc_R_th_from_voltage(voltage, V_0, V_5)
                            if R_val:
                                T_val = temp_from_resistance_C(R_val)

                        text = (
                            f"{entry['antenna']}<br>"
                            f"Terminal: {entry['terminal']}<br>"
                            f"Cable: {entry['cable']}<br>"
                            f"Resistor Value: 10k<br>"
                            f"Voltage: {voltage:.4f}"
                            + (f"<br>R: {R_val:.2f} Ω" if R_val else "<br>R: -")
                        )

                        style = f"border: 1px solid gray; padding: 5px; background-color: {bg_colors[color]}; color: black;"
                    else:
                        voltage = entry.get('voltage')
                        R_val = None
                        T_val = None
                        if isinstance(voltage, (int, float)) and voltage > MIN_V and V_0 is not None and V_5 is not None:
                            R_val = calc_R_th_from_voltage(voltage, V_0, V_5)
                            if R_val:
                                T_val = temp_from_resistance_C(R_val)

                        text = f"{entry['antenna']}<br>Terminal: {entry['terminal']}<br>Cable: {entry['cable']}<br>Voltage: {voltage:.4f}" \
                            + (f"<br>R: {R_val:.2f} Ω" if R_val else "<br>R: -") \
                            + (f"<br>T: {T_val:.2f} °C" if T_val else "<br>T: -")
                        
                        # Use highlight color if temperature is above threshold
                        if T_val and T_val > TEMP_THRESHOLD:
                            style = f"border: 2px solid red; padding: 8px; background-color: {highlight_bg_colors[color]}; color: black; font-weight: bold;"
                        else:
                            style = f"border: 1px solid gray; padding: 8px; background-color: {bg_colors[color]}; color: black;"
                else:
                    text = f"{color}: missing"
                    style = "border: 1px solid gray; padding: 8px; background-color: #FF9999; color: black;"
                label = QLabel(text)
                label.setWordWrap(True)
                label.setStyleSheet(style)
                grid.addWidget(label, row, col_pos, 1, 3)
            row += 1

        ground5v = QLabel(f"<b>Ground/5V</b>")
        ground5v.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ground5v.setStyleSheet("padding:6px;")
        grid.addWidget(ground5v, row, 0, 1, total_units)
        row += 1

        # Bottom: six equally sized items, each spans 2 units
        labels = []
        labels.append(f"Ground1 (AIN0): {ain0 if ain0 is not None else '-'}")
        labels.append(f"Ground2 (AIN2): {ain2 if ain2 is not None else '-'}")
        labels.append(f"Avg Ground: {V_0 if V_0 is not None else '-'}")
        labels.append(f"5V1 (AIN1): {ain1 if ain1 is not None else '-'}")
        labels.append(f"5V2 (AIN3): {ain3 if ain3 is not None else '-'}")
        labels.append(f"Avg 5V (doubled): {V_5 if V_5 is not None else '-'}")

        for i, txt in enumerate(labels):
            col_pos = i * 2
            l = QLabel(txt)
            l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            l.setStyleSheet("border: 1px solid gray; padding: 6px; background-color: #EEEEEE; color: black;")
            l.setWordWrap(True)
            grid.addWidget(l, row, col_pos, 1, 2)

        scroll.setWidget(content)
        layout.addWidget(scroll)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    viewer = AntennaViewer()
    viewer.show()
    sys.exit(app.exec())

def show_antenna_viewer():
    try:
        app = QApplication.instance()  # check if an app exists already
        if not app:
            app = QApplication(sys.argv)
        viewer = AntennaViewer()
        viewer.show()
        # At this point, the window is shown; we return True for success
        return True
    except Exception as e:
        print(f"Failed to launch viewer: {e}")
        return False