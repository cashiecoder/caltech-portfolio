import json
import json5
from pathlib import Path
from typing import Union

def get_ain_numbers_from_json(filepaths: Union[str, list[str]]):
    """
    Reads one or more JSON/JSON5 files (with terminal-cable structure), converts them into Python dictionaries,
    and extracts key-value pairs where the terminal starts with "AIN".

    Args:
        filepaths (str | list[str]): Path to a JSON/JSON5 file or a list of file paths.

    Returns:
        dict: A dictionary containing dictionaries keyed by file stem (e.g., x2, x3, etc.)
              with only the key-value pairs where the terminal starts with "AIN".
    """
    # Normalize input into a list
    if isinstance(filepaths, str):
        filepaths = [filepaths]

    ain_arrays = {}
    for file_path in filepaths:
        ain_numbers = {}
        try:
            with open(file_path, 'r') as file:
                # Pick parser based on extension
                if Path(file_path).suffix.lower() == ".json":
                    data = json.load(file)
                elif Path(file_path).suffix.lower() == ".json5":
                    data = json5.load(file)
                else:
                    raise ValueError(f"Input file {Path(file_path).name} is not JSON or JSON5")

                for key, value in data.items():
                    # Handle new structure: {"terminal": ..., "cable": ...}
                    if isinstance(value, dict) and 'terminal' in value and isinstance(value['terminal'], str):
                        if value['terminal'].startswith('AIN'):
                            ain_numbers[key] = value['terminal']
                    # Optional: handle old style strings
                    elif isinstance(value, str) and value.startswith('AIN'):
                        ain_numbers[key] = value

        except FileNotFoundError:
            print(f"Error: File not found at {file_path}")
        except Exception as e:
            print(f"Error reading {file_path}: {e}")

        # Use filename (without extension) as dict key
        address = Path(file_path).stem
        ain_arrays[address] = ain_numbers

    return ain_arrays


# Example usage
file_paths = [r'C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\variables\mux80/x2.json', r'C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\variables\mux80/x3.json', r'C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\variables\mux80/x4.json', r'C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\variables\mux80/x5.json']
ain_arrays = get_ain_numbers_from_json(file_paths)
