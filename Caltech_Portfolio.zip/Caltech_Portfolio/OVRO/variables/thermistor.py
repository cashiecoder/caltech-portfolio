from scipy.constants import convert_temperature as ct

beta = 3892
r_0 = 10000
t_0 = ct(25, "C", "K")
vs = None
R_series = 32400