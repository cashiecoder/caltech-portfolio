HANDLE_INFO =  {
    "usb": ["ANY", "USB", "ANY"],
    "sprite": ["ANY", "ETHERNET", "127.0.0.1:6558"],
    "ethernet": ["ANY", "ETHERNET", "192.168.65.58"]
}