from datetime import datetime

current_datetime = datetime.now()

# Format the datetime into a string (e.g., YYYY-MM-DD HH:MM:SS)
formatted_date = current_datetime.strftime("%Y%m%d-%H%M%S")

formatted_filename = formatted_date + ".json"

foldername = "thermistor_data"

FOLDEROLD = r"C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\thermistor_data"
FOLDER = r"/home/thavel/ovro-dsa2k-test05dish/thermistor_data"