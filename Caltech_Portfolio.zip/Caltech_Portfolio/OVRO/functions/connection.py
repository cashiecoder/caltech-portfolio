from labjack import ljm
from variables import connection
from functions.util import printInfo

HANDLE_INFO = connection.HANDLE_INFO["usb"]

try:
    # Open LabJack connection
    if len(HANDLE_INFO) != 3:
        raise ValueError("Expected exactly 3 parameters: deviceType, connectionType, identifier")
    handle = ljm.openS(*HANDLE_INFO)
    print(f"Device opened. Handle: {handle}")

    printInfo(handle)

    # Close the device
    ljm.close(handle)

except Exception as e:
    print(f"Failed to connect or read data:\n{e}")
