import socket
import struct
from labjack import ljm

def printInfo(handle):
    try:
        device_type, connection_type, serial_number, ip_signed, port, max_bytes_per_mb = ljm.getHandleInfo(handle)
        print("Device Info:")
        print(f" • Device Type: {device_type}")
        print(f" • Connection Type: {connection_type}")
        print(f" • Serial Number: {serial_number}")
        print(f" • IP Address (as int): {ip_signed}")
        ip_unsigned = ip_signed & 0xFFFFFFFF
        connected_ip = socket.inet_ntoa(struct.pack('>I', ip_unsigned))
        print(f" • IP Address: {connected_ip}")  
        print(f" • Port: {port}")
        print(f" • Max Bytes per MB: {max_bytes_per_mb}")

        ethernet_ip = ljm.eReadName(handle, "ETHERNET_IP")
        print(f"Ethernet IP register value: {ethernet_ip}")
        ip_int = int(ethernet_ip)
        ip_str = socket.inet_ntoa(struct.pack('>I', ip_int))
        print(f"Ethernet IP address: {ip_str}")
    except Exception as e:
        print(f"Failed to connect or read data:\n{e}")