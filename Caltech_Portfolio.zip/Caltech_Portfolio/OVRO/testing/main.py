from gather_data import gather_data
from newchart import show_antenna_viewer

def main():
    if gather_data():
        print("Data successfully collected.")
        if show_antenna_viewer():
            print("Data successfully displayed.")
        else:
            print("Data failed to display.")
    else: 
        print("Data failed to collect.")

if __name__ == "__main__":
    main()