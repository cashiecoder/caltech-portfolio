import subprocess
import time
import csv
import statistics
from datetime import datetime, timezone
from labjack import ljm
from functions.util import printInfo
from variables import connection
from variables.variables import FOLDER
from dish_thermistor_heatmap import calc_R_th_from_voltage, temp_from_resistance_C
from dish_thermistor_heatmap import R_SERIES, BETA, R_0, T0_K

HANDLE_INFO = connection.HANDLE_INFO["sprite"]


def gather_data(n=100):
    success = False  # Assume failure by default
    data_rows = []

    if HANDLE_INFO == connection.HANDLE_INFO["sprite"]:
        tunnel = subprocess.Popen(
            ["ssh", "-N", "-L", "6558:192.168.65.58:502", "sprite"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        print("SSH tunnel started on localhost:6558. Waiting a moment for it to establish...")
        time.sleep(5)

    try:
        handle = ljm.openS(*HANDLE_INFO)
        print(f"Device opened. Handle: {handle}")
        printInfo(handle)

        channel_names = ["AIN0", "AIN1", "AIN2", "AIN3"]

        for i in range(n):
            values = ljm.eReadNames(handle, len(channel_names), channel_names)
            vs = statistics.mean([values[1] * 2, values[3] * 2])
            gnd = statistics.mean([values[0], values[2]])
            p1c_blue = ljm.eReadName(handle, "AIN122")

            resistance = calc_R_th_from_voltage(p1c_blue, gnd, vs, R_SERIES)
            temperature = temp_from_resistance_C(resistance, R_0, BETA, T0_K)

            timestamp = datetime.now(timezone.utc).isoformat()
            data_rows.append([timestamp, vs, gnd, p1c_blue, resistance, temperature])

            time.sleep(1)  # short delay between readings

        ljm.close(handle)
        success = True

        # Save to CSV with UTC timestamp as filename
        filename = f"{FOLDER}/{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.csv"
        with open(filename, mode="w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp_utc", "vs", "gnd", "p1c_blue", "resistance", "temperature_C"])
            writer.writerows(data_rows)

        print(f"Saved {len(data_rows)} rows to {filename}")

    except Exception as e:
        print(f"Failed to connect or read data:\n{e}")
        success = False

    finally:
        if HANDLE_INFO == connection.HANDLE_INFO["sprite"]:
            print("Closing SSH tunnel...")
            tunnel.terminate()
            tunnel.wait()

    return success


if __name__ == "__main__":
    if gather_data(100):
        print("Data collection succeeded")
    else:
        print("Data collection failed")