import subprocess
import time
import csv
import statistics
from datetime import datetime, timezone
from labjack import ljm
from functions.util import printInfo
from variables import connection
from variables.variables import FOLDER
from dish_thermistor_heatmap import calc_R_th_from_voltage, temp_from_resistance_C
from dish_thermistor_heatmap import R_SERIES, BETA, R_0, T0_K

from collections import deque

# Matplotlib for live plotting of last N readings
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

HANDLE_INFO = connection.HANDLE_INFO["sprite"]
LAST_N = 100         # how many recent points to show
SAMPLE_INTERVAL = 0.5  # seconds between samples


def gather_data():
    success = False  # Assume failure by default
    data_rows = []

    # Prepare SSH tunnel if needed
    if HANDLE_INFO == connection.HANDLE_INFO["sprite"]:
        tunnel = subprocess.Popen(
            ["ssh", "-N", "-L", "6558:192.168.65.58:502", "sprite"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        print("SSH tunnel started on localhost:6558. Waiting a moment for it to establish...")
        time.sleep(5)

    # Prepare plotting structures
    times_deque = deque(maxlen=LAST_N)
    temps_deque = deque(maxlen=LAST_N)
    plotting_enabled = True

    try:
        # Try to initialize a live plot; if it fails (e.g., headless), disable plotting
        try:
            plt.ion()
            fig, ax = plt.subplots(figsize=(8, 4))
            line, = ax.plot([], [])  # no color specified
            ax.set_xlabel("Time (UTC)")
            ax.set_ylabel("Temperature (°C)")
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M:%S"))
            fig.autofmt_xdate()
            ax.set_title(f"Last {LAST_N} temperatures")
            plt.show(block=False)
        except Exception as e:
            print(f"Warning: plotting disabled ({e}) — continuing without live plot.")
            plotting_enabled = False

        handle = ljm.openS(*HANDLE_INFO)
        print(f"Device opened. Handle: {handle}")
        printInfo(handle)

        channel_names = ["AIN0", "AIN1", "AIN2", "AIN3"]

        # Save to CSV with UTC timestamp as filename (session-based)
        filename = f"{FOLDER}/{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.csv"
        with open(filename, mode="w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp_utc", "vs", "gnd", "p1c_blue", "resistance", "temperature_C"])

            print("Starting data collection... Press Ctrl+C to stop.")
            while True:
                # Read channels
                values = ljm.eReadNames(handle, len(channel_names), channel_names)
                vs = statistics.mean([values[1] * 2, values[3] * 2])
                gnd = statistics.mean([values[0], values[2]])
                p1c_blue = ljm.eReadName(handle, "AIN122")

                resistance = calc_R_th_from_voltage(p1c_blue, gnd, vs, R_SERIES)
                temperature = temp_from_resistance_C(resistance, R_0, BETA, T0_K)

                timestamp_dt = datetime.now(timezone.utc)
                timestamp = timestamp_dt.isoformat()
                row = [timestamp, vs, gnd, p1c_blue, resistance, temperature]
                data_rows.append(row)

                # Write immediately to CSV
                writer.writerow(row)
                f.flush()

                # Print row to console
                print(row)

                # Update plot buffers
                if plotting_enabled:
                    try:
                        times_deque.append(timestamp_dt)
                        temps_deque.append(temperature)

                        # Update line data
                        line.set_data(list(times_deque), list(temps_deque))
                        ax.relim()
                        ax.autoscale_view()

                        # Ensure x-axis ticks show times properly
                        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
                        fig.canvas.draw()
                        fig.canvas.flush_events()
                        # short pause to allow GUI event loop to process (non-blocking)
                        plt.pause(0.001)
                    except Exception as pe:
                        # If plotting fails mid-run, warn once and disable it
                        print(f"Plotting error, disabling live plot: {pe}")
                        plotting_enabled = False

                time.sleep(SAMPLE_INTERVAL)  # wait between readings

    except KeyboardInterrupt:
        print("\nStopping data collection (Ctrl+C pressed).")
        success = True

    except Exception as e:
        print(f"Failed to connect or read data:\n{e}")
        success = False

    finally:
        # Close labjack handles and plot
        try:
            ljm.closeAll()
        except Exception:
            pass

        if plotting_enabled:
            try:
                plt.ioff()
                plt.close(fig)
            except Exception:
                pass

        if HANDLE_INFO == connection.HANDLE_INFO["sprite"]:
            print("Closing SSH tunnel...")
            try:
                tunnel.terminate()
                tunnel.wait()
            except Exception:
                pass

    return success


if __name__ == "__main__":
    if gather_data():
        print("Data collection finished successfully")
    else:
        print("Data collection failed")
