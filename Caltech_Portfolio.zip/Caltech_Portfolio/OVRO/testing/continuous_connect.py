import subprocess
import sys
import time
from labjack import ljm
from gather_data import HANDLE_INFO


def kill_ssh_processes():
    """Kill any ssh process bound to port 6558"""
    subprocess.run(["pkill", "-f", "ssh -f -N -L 6558"], check=False)


def run_script():
    """Run the reset.sh script to create a new SSH tunnel"""
    script_path = "reset.sh"
    subprocess.run(
        ["bash", script_path],
        cwd="/home/thavel/ovro-dsa2k-test05dish",
        check=True,
    )


def test_connection():
    """Try to open a LabJack connection"""
    try:
        handle = ljm.openS(*HANDLE_INFO)
        ljm.close(handle)
        return True
    except Exception:
        return False


def main():
    if test_connection():
        print("Connection successful (already up).")
        sys.exit(0)

    kill_ssh_processes()
    print("Killed any old SSH tunnels.")

    run_script()
    print("Started new SSH tunnel, waiting for it to establish...")

    # Wait a bit for SSH tunnel to come up
    for attempt in range(5):
        time.sleep(2)  # wait 2s per attempt
        if test_connection():
            print(f"Connection successful on attempt {attempt+1}!")
            sys.exit(0)

    print("Connection failed after multiple attempts, aborting.")
    sys.exit(1)


if __name__ == "__main__":
    main()
