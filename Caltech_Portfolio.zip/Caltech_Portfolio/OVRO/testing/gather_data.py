from time import sleep
import os
import json
from datetime import datetime, timezone
from labjack import ljm
from functions.util import printInfo
from variables import connection
from variables.ain_arrays import ain_arrays
import statistics
from variables.variables import FOLDER
from dish_thermistor_heatmap import calc_R_th_from_voltage, temp_from_resistance_C

HANDLE_INFO = connection.HANDLE_INFO["sprite"]

def gather_data(retry=False):
    success = False  # Assume failure by default

    """
    if HANDLE_INFO == connection.HANDLE_INFO["sprite"]:
        tunnel = subprocess.Popen(
            ["ssh", "-N", "-L", "6558:192.168.65.58:502", "sprite"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        print("SSH tunnel started on localhost:6558. Waiting a moment for it to establish...")
        time.sleep(2)
    """

    try:
        handle = ljm.openS(*HANDLE_INFO)
        print(f"Device opened. Handle: {handle}")
        printInfo(handle)

        channel_names = ["AIN0", "AIN1", "AIN2", "AIN3"]
        values = ljm.eReadNames(handle, len(channel_names), channel_names)
        vs = statistics.mean([values[1]*2, values[3]*2])
        gnd = statistics.mean([values[0], values[2]])
        print(f"VS: {vs}, GND: {gnd}")

        filename = ""

        for block, channels in ain_arrays.items():
            for key, entry in channels.items():
                terminal = entry.get("terminal")
                if terminal and terminal.startswith("AIN"):
                    try:
                        voltage = ljm.eReadName(handle, terminal)
                        entry["voltage"] = voltage
                        antenna = entry.get("antenna") or ""
                        ignoreResistance = terminal in channel_names
                        ignoreTemp = antenna.startswith("air_orange") or antenna.startswith("air_green") or ignoreResistance
                        resistance = calc_R_th_from_voltage(voltage, gnd, vs)
                        if not ignoreResistance:
                            entry["resistance"] = resistance
                        else:
                            entry["resistance"] = None
                        if not ignoreTemp:
                            entry["temperature"] = temp_from_resistance_C(resistance)
                        else:
                            entry["temperature"] = None
                        print(f"{terminal}: {voltage}")
                    except Exception as read_err:
                        print(f"Failed to read {terminal}: {read_err}")
                        entry["voltage"] = None
                        entry["resistance"] = None
                        entry["temperature"] = None

        os.makedirs(FOLDER, exist_ok=True)
        filepath = f"{FOLDER}/{filename + '_' if filename != '' else ''}{datetime.now().astimezone(timezone.utc).isoformat()}.json"
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(ain_arrays, f, indent=2)

        print(f"Data saved to {filepath} at {datetime.now().strftime('%Y%m%d_%H%M%S')}")
        ljm.close(handle)

        success = True

    except Exception as e:
        print(f"Failed to connect or read data:\n{e}")
        success = False

    finally:
        if HANDLE_INFO == connection.HANDLE_INFO["sprite"]:
            #print("Closing SSH tunnel...")
            #tunnel.terminate()
            #tunnel.wait()
            pass
        if not success and not retry:
            sleep(60)
            gather_data(retry=True)
        elif not success and retry:
            pass

    return success

if __name__ == "__main__":
    if gather_data():
        print("Data collection succeeded")
    else:
        print("Data collection failed")
