#!/usr/bin/env python3
"""
Debuggable thermistor JSON processor.

Usage:
    python therm_debug.py --folder "C:\path\to\testdata" [--debug] [--min-v 0.1] [--force-v0 0.0 --force-v5 5.0]

Outputs:
  - results_debug.csv: one row per input file/column with raw_v, V_0, V_5, R_th, T_c, reason
  - console debug lines if --debug is passed
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# --- Thermistor defaults (same defaults as before) ---
DEFAULT_R_SERIES = 32400.0
DEFAULT_BETA = 3892.0
DEFAULT_R0 = 10000.0
DEFAULT_T0_K = 25.0 + 273.15  # assume 25°C if not provided

# Try to import variables. If user has variables.thermistor, use it.
try:
    from variables import thermistor  # type: ignore
except Exception:
    thermistor = None

R_series = float(getattr(thermistor, "R_series", DEFAULT_R_SERIES)) if thermistor else DEFAULT_R_SERIES
beta = float(getattr(thermistor, "beta", DEFAULT_BETA)) if thermistor else DEFAULT_BETA
r_0 = float(getattr(thermistor, "r_0", DEFAULT_R0)) if thermistor else DEFAULT_R0
t_0 = getattr(thermistor, "t_0", None) if thermistor else None
if t_0 is None:
    t_0 = DEFAULT_T0_K
else:
    t_0 = float(t_0)
    if t_0 < 100.0:  # likely provided in °C -> convert
        t_0 = t_0 + 273.15

# other constants
VOLTAGE_GND_ORDER = ["ain0", "ain1", "ain2", "ain3"]


# ---------------- helper utilities ----------------
def parse_voltage(v) -> Optional[float]:
    """Try to convert various representations into a float voltage (returns None if not parseable)."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return None
        # handle comma decimal like "3,456"
        s = s.replace(",", ".") if s.count(",") == 1 and s.count(".") == 0 else s
        # remove non-numeric trailing/leading (like "3.45 V" or "N/A")
        # keep + - and digits and decimal point and exponent
        allowed = set("0123456789+-.eE")
        cleaned = "".join(ch for ch in s if ch in allowed)
        if cleaned == "" or cleaned.lower() in ("na", "nan"):
            return None
        try:
            return float(cleaned)
        except Exception:
            return None
    return None


def calc_R_th_from_voltage(V_t: float, V_0: float, V_5: float, R_series_local: float = R_series) -> Tuple[Optional[float], str]:
    """Return (R_th or None, reason string)."""
    if V_t is None:
        return None, "raw_v_missing"
    if V_0 is None or V_5 is None:
        return None, "V0_or_V5_missing"
    Vs = V_5 - V_0
    V = V_t - V_0
    if Vs <= 0:
        return None, f"Vs_nonpositive (V5-V0={Vs:.6g})"
    if V <= 0:
        return None, f"V_local_nonpositive (V_t-V0={V:.6g})"
    if V >= Vs:
        return None, f"V_local_ge_Vs (V={V:.6g}, Vs={Vs:.6g})"
    denom = Vs - V
    if math.isclose(denom, 0.0):
        return None, "denom_too_small"
    try:
        R_th = (V * R_series_local) / denom
    except Exception as e:
        return None, f"calc_exception:{e}"
    if not math.isfinite(R_th):
        return None, "R_not_finite"
    if R_th <= 0:
        return None, "R_nonpositive"
    return R_th, ""


def temp_from_resistance_C(R: float, r0: float = r_0, beta_val: float = beta, t0_k: float = t_0) -> Tuple[Optional[float], str]:
    """Return (temp_C or None, reason)."""
    if R is None:
        return None, "R_missing"
    if R <= 0:
        return None, "R_nonpositive"
    try:
        ln_term = math.log(R / r0)
        invT = (1.0 / t0_k) + (1.0 / beta_val) * ln_term
        if invT == 0:
            return None, "invT_zero"
        T_k = 1.0 / invT
        T_c = T_k - 273.15
        if not math.isfinite(T_c):
            return None, "T_not_finite"
        return T_c, ""
    except Exception as e:
        return None, f"temp_exception:{e}"


# ------------- JSON loading helpers --------------
def read_json_files(folder: Path) -> Tuple[Dict[str, Dict[str, float]], List[str]]:
    """Load JSONs and return data map and discovered non-AIN column order."""
    files = sorted([p for p in folder.iterdir() if p.suffix.lower() == ".json"])
    data: Dict[str, Dict[str, float]] = {}
    columns_order: List[str] = []
    for p in files:
        try:
            with open(p, "r") as fh:
                content = json.load(fh)
        except Exception as e:
            print(f"Failed to parse {p.name}: {e}")
            continue
        voltages: Dict[str, float] = {}
        # support content being dict of sections containing dictionary of datapoints
        if isinstance(content, dict):
            for section_key, section_val in content.items():
                if isinstance(section_val, dict):
                    for k, info in section_val.items():
                        # protective checks
                        if not isinstance(info, dict):
                            continue
                        term = info.get("terminal")
                        raw_v = info.get("voltage")
                        if term is None:
                            continue
                        t = str(term).lower()
                        voltages[t] = raw_v
                        if t not in VOLTAGE_GND_ORDER and t not in columns_order:
                            columns_order.append(t)
        # fallback: if content itself is a list of items with terminal/voltage
        elif isinstance(content, list):
            for info in content:
                if not isinstance(info, dict):
                    continue
                term = info.get("terminal")
                raw_v = info.get("voltage")
                if term is None:
                    continue
                t = str(term).lower()
                voltages[t] = raw_v
                if t not in VOLTAGE_GND_ORDER and t not in columns_order:
                    columns_order.append(t)
        else:
            # unknown format: just skip
            continue
        data[p.name] = voltages
    # append any present AINs at the end in order
    cols = columns_order + [t for t in VOLTAGE_GND_ORDER if any(t == k for v in data.values() for k in v)]
    return data, cols


# ---------------- main processing ----------------
def process_folder(folder: Path, min_v_to_convert: float, force_v0: Optional[float], force_v5: Optional[float],
                   debug: bool):
    data, columns = read_json_files(folder)
    if not data:
        print("No JSON data found in folder:", folder)
        return

    out_rows = []
    success = 0
    fail = 0

    for fname, row in data.items():
        # compute V_0 as average of ain0 & ain2 unless overridden
        if force_v0 is not None:
            V_0 = force_v0
        else:
            ain0 = parse_voltage(row.get("ain0"))
            ain2 = parse_voltage(row.get("ain2"))
            v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
            V_0 = (sum(v0_list) / len(v0_list)) if v0_list else None

        # compute V_5 as average of ain1 & ain3 unless overridden
        if force_v5 is not None:
            V_5 = force_v5
        else:
            ain1 = parse_voltage(row.get("ain1"))
            ain3 = parse_voltage(row.get("ain3"))
            v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
            V_5 = (sum(v5_list) / len(v5_list)) if v5_list else None

        if debug:
            print(f"File: {fname}  V_0={V_0!r}  V_5={V_5!r}")

        for col in columns:
            raw_val = row.get(col)
            parsed_v = parse_voltage(raw_val)
            reason = ""
            R_th = None
            T_c = None

            if parsed_v is None:
                reason = "raw_v_unparsable_or_missing"
            elif parsed_v <= min_v_to_convert:
                reason = f"raw_v_below_min ({parsed_v:.6g} <= {min_v_to_convert:.6g})"
            else:
                R_th, reason_R = calc_R_th_from_voltage(parsed_v, V_0, V_5)
                if reason_R:
                    reason = reason_R
                else:
                    T_c, reason_T = temp_from_resistance_C(R_th)
                    if reason_T:
                        reason = reason_T

            # update counters
            if reason == "":
                success += 1
            else:
                fail += 1

            out_rows.append({
                "filename": fname,
                "column": col,
                "raw_v": parsed_v if parsed_v is not None else "",
                "V_0": V_0 if V_0 is not None else "",
                "V_5": V_5 if V_5 is not None else "",
                "R_th": f"{R_th:.6g}" if isinstance(R_th, (int, float)) else "",
                "T_c": f"{T_c:.6g}" if isinstance(T_c, (int, float)) else "",
                "reason": reason
            })

            if debug:
                print(f"  {col}: raw={parsed_v!r} -> R={R_th!r}  T={T_c!r}  reason='{reason}'")

    # write CSV
    outpath = Path.cwd() / "results_debug.csv"
    with open(outpath, "w", newline="") as csvf:
        writer = csv.DictWriter(csvf, fieldnames=["filename", "column", "raw_v", "V_0", "V_5", "R_th", "T_c", "reason"])
        writer.writeheader()
        for r in out_rows:
            writer.writerow(r)

    print(f"Processed {len(data)} files, {len(out_rows)} channel-rows. Success={success}, Fail={fail}")
    print("Wrote:", outpath)


# ---------------- CLI ----------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", "-f", required=True, help="Folder containing .json files")
    parser.add_argument("--debug", action="store_true", help="Print detailed debug lines")
    parser.add_argument("--min-v", type=float, default=0.1, help="Minimum voltage to attempt conversion (default 0.1)")
    parser.add_argument("--force-v0", type=float, default=None, help="Force V_0 (override AIN0/2 averaging)")
    parser.add_argument("--force-v5", type=float, default=None, help="Force V_5 (override AIN1/3 averaging)")
    args = parser.parse_args()

    folder = Path(args.folder)
    if not folder.exists() or not folder.is_dir():
        print("Folder invalid:", folder)
        return

    process_folder(folder, args.min_v, args.force_v0, args.force_v5, args.debug)


if __name__ == "__main__":
    main()
