from therm_gui_fixed import temp_from_resistance_C
from variables.thermistor import beta, r_0, t_0
import math

def sanity_test_temps():
    """Quick sanity check for thermistor conversion."""
    test_points = {
        1000: "~85–90 °C (hot)",
        5000: "~40 °C (warm)",
        10000: "~25 °C (room)",
        33000: "~10 °C (cold)",
    }
    for R, expect in test_points.items():
        T = temp_from_resistance_C(R)
        print(f"R={R} Ω -> T={T:.2f} °C, expected {expect}")

# Run the test
sanity_test_temps()
def debug_temp(R, r0=r_0, beta_val=beta, t0_k=t_0):
    """Step through Beta model calculation for debugging."""
    ln_term = math.log(R / r0)
    invT = (1.0 / t0_k) + (1.0 / beta_val) * ln_term
    T_k = 1.0 / invT
    T_c = T_k - 273.15
    print(f"R={R}")
    print(f"  ln(R/R0)={ln_term}")
    print(f"  1/T0={1/t0_k}")
    print(f"  invT={invT}")
    print(f"  T_k={T_k}")
    print(f"  T_c={T_c}")
    return T_c

T = debug_temp(100000)