#!/usr/bin/env python3
"""
Thermistor JSON reader + GUI (PyQt6)

- Reads JSON files from a folder (default is your original folder).
- Converts measured AIN voltages to thermistor resistances using a series resistor.
- Converts resistances to temperature using the beta model.
- Shows multiple Qt windows: raw voltages, low-voltage rows, resistances, temperatures, and stats.

Usage:
    python therm_gui.py --folder "C:\path\to\testdata" [--debug] [--selftest]

Keep a `variables.py` next to this script that exposes `thermistor` (optional). If not present,
defaults are used (R_series=32400, beta=3892, r_0=10000, t_0=25°C assumed).
"""
from __future__ import annotations
import argparse
import json
import math
import os
import sys
from pathlib import Path
from statistics import mean, stdev
from typing import Dict, List, Optional, Tuple

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget
)

# Attempt to import user-supplied thermistor variables (same pattern you used)
try:
    from variables import thermistor  # type: ignore
except Exception:
    thermistor = None  # fallback handled below

# ----------------- Config / Defaults -----------------
DEFAULT_FOLDER = r"C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\testdata"
VOLTAGE_GND_ORDER = ["ain0", "ain1", "ain2", "ain3"]
MAX_R = 200_000
MIN_V_TO_CONVERT = 0.1  # only convert voltages greater than this
GROUP_LABELS = ["1k", "10k", "32k", "5.5k"]  # label order for every-4th grouping

# Read thermistor params from user-supplied module if present
R_series = getattr(thermistor, "R_series", 32400) if thermistor is not None else 32400
beta = getattr(thermistor, "beta", 3892) if thermistor is not None else 3892
r_0 = getattr(thermistor, "r_0", 10000) if thermistor is not None else 10000
t_0 = getattr(thermistor, "t_0", None) if thermistor is not None else None  # expected in Kelvin ideally

# If no t_0 given assume 25°C -> Kelvin. If t_0 looks small (<100) assume it's in °C and convert.
if t_0 is None:
    t_0 = 25.0 + 273.15
elif t_0 < 100:
    # common mistake: user provided Celsius; convert automatically
    t_0 = float(t_0) + 273.15

# ----------------- Helper Functions -----------------
def dbg_print(enabled: bool, *args, **kwargs):
    if enabled:
        print(*args, **kwargs)

def calc_R_th_from_voltage(V_t: float, V_0: float, V_5: float, R_series_local: float = R_series,
                           debug: bool = False) -> Optional[float]:
    """
    Compute thermistor resistance from measured V_t using divider formula.
    Returns None for invalid values or if result is out-of-range.
    """
    if V_0 is None or V_5 is None:
        if debug:
            print("calc_R: missing V_0 or V_5")
        return None
    Vs_local = V_5 - V_0
    V_local = V_t - V_0
    # Guards: vs must be >0 and V_local must be strictly between 0 and Vs_local
    if Vs_local <= 0 or V_local <= 0 or V_local >= Vs_local or math.isclose(Vs_local - V_local, 0.0):
        if debug:
            print(f"calc_R: invalid voltages V_0={V_0!r}, V_5={V_5!r}, V_t={V_t!r} -> Vs={Vs_local!r}, V={V_local!r}")
        return None
    try:
        R_th = (V_local * R_series_local) / (Vs_local - V_local)
    except Exception as e:
        if debug:
            print("calc_R exception:", e)
        return None
    if not math.isfinite(R_th) or R_th <= 0 or R_th > MAX_R:
        if debug:
            print(f"calc_R: out-of-range R_th={R_th!r}")
        return None
    return R_th

def temp_from_resistance_C(R: float, r0: float = r_0, beta_val: float = beta, t0_k: float = t_0,
                           debug: bool = False) -> Optional[float]:
    """
    Convert resistance to temperature (°C) using the Beta model:
        1/T = 1/T0 + (1/beta) * ln(R / r0)
    Returns None for invalid inputs.
    """
    if R is None or R <= 0:
        return None
    try:
        ln_term = math.log(R / r0)
        invT = (1.0 / t0_k) + (1.0 / beta_val) * ln_term
        if invT == 0:
            if debug:
                print("temp_from_resistance: invT == 0")
            return None
        T_k = 1.0 / invT
        T_c = T_k - 273.15
        if not math.isfinite(T_c):
            if debug:
                print("temp_from_resistance: result not finite")
            return None
        return T_c
    except Exception as e:
        if debug:
            print("temp_from_resistance exception:", e)
        return None

def compute_stats(values: List[float]) -> Tuple[str, str, str, str, str]:
    """Return formatted (mean, min, max, stddev, stddev_pct)."""
    if not values:
        return ("", "", "", "", "")
    mu = mean(values)
    mn = min(values)
    mx = max(values)
    sd = stdev(values) if len(values) > 1 else 0.0
    if mu != 0 and math.isfinite(mu):
        sd_pct = (sd / abs(mu)) * 100.0
        sd_pct_str = f"{sd_pct:.2f} %"
    else:
        sd_pct_str = ""
    return (f"{mu:.2f}", f"{mn:.2f}", f"{mx:.2f}", f"{sd:.2f}", sd_pct_str)

# ----------------- Core Processing -----------------
def load_json_files(folder: Path, debug: bool = False) -> Tuple[Dict[str, Dict[str, float]], List[str]]:
    """Load all .json files from folder and normalize terminal names to lowercase.
       Returns (data_map, discovered_columns_list)."""
    json_files = sorted([p for p in folder.iterdir() if p.suffix.lower() == ".json"])
    data: Dict[str, Dict[str, float]] = {}
    columns_list: List[str] = []

    for p in json_files:
        try:
            with open(p, "r") as fh:
                content = json.load(fh)
        except Exception as e:
            dbg_print(debug, f"Failed to read {p}: {e}")
            continue

        voltages: Dict[str, float] = {}
        # content is presumably a dict of sections -> {key: {"terminal": "...", "voltage": ...}, ...}
        for section in content:
            section_obj = content[section]
            if not isinstance(section_obj, dict):
                continue
            for key, info in section_obj.items():
                term = info.get("terminal")
                if term is None:
                    continue
                t_lower = str(term).lower()
                val = info.get("voltage")
                voltages[t_lower] = val
                if t_lower not in VOLTAGE_GND_ORDER and t_lower not in columns_list:
                    columns_list.append(t_lower)

        data[p.name] = voltages

    # final columns: discovered non-ain columns followed by any present AINs in VOLTAGE_GND_ORDER
    columns = columns_list + [t for t in VOLTAGE_GND_ORDER if any(t == k for v in data.values() for k in v)]
    dbg_print(debug, f"Loaded {len(data)} JSON files, columns: {columns}")
    return data, columns

def process_all(data: Dict[str, Dict[str, float]], columns: List[str], debug: bool = False):
    """
    For each file: compute V_0 and V_5, convert voltages > MIN_V_TO_CONVERT to resistances and temps.
    Returns (resistances_by_file, temps_by_file).
    """
    resistances_by_file: Dict[str, Dict[str, Optional[float]]] = {}
    temps_by_file: Dict[str, Dict[str, Optional[float]]] = {}

    for fname, volts in data.items():
        res_map: Dict[str, Optional[float]] = {}
        temp_map: Dict[str, Optional[float]] = {}

        # compute V_0 average from AIN0 and AIN2 (if present)
        ain0 = volts.get("ain0")
        ain2 = volts.get("ain2")
        v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
        V_0 = sum(v0_list) / len(v0_list) if v0_list else None

        # compute V_5 average from AIN1 and AIN3 (if present)
        ain1 = volts.get("ain1")
        ain3 = volts.get("ain3")
        v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
        # IMPORTANT: do NOT multiply by 2. Average only.
        V_5 = (sum(v5_list) / len(v5_list)) if v5_list else None

        dbg_print(debug, f"[{fname}] V_0={V_0!r}  V_5={V_5!r}")

        for col in columns:
            raw_v = volts.get(col)
            if isinstance(raw_v, (int, float)) and raw_v > MIN_V_TO_CONVERT and (V_0 is not None) and (V_5 is not None):
                R_th = calc_R_th_from_voltage(raw_v, V_0, V_5, debug=debug)
                res_map[col] = R_th
                temp_map[col] = temp_from_resistance_C(R_th, debug=debug) if R_th is not None else None
            else:
                res_map[col] = None
                temp_map[col] = None

        resistances_by_file[fname] = res_map
        temps_by_file[fname] = temp_map

    return resistances_by_file, temps_by_file

def group_and_stats(columns: List[str], resistances_by_file: Dict[str, Dict[str, Optional[float]]],
                    temps_by_file: Dict[str, Dict[str, Optional[float]]], debug: bool = False):
    """
    Group columns into 4 groups by offset (0..3) and compute stats per group.
    Returns (groups, res_stats_data, temp_stats_data, group_values_res, group_values_temp)
    """
    non_gnd_cols = [c for c in columns if c not in VOLTAGE_GND_ORDER]
    groups = [non_gnd_cols[i::4] for i in range(4)]
    # If number of groups doesn't match labels, adjust labels to discovered length:
    labels = GROUP_LABELS[:len(groups)]

    group_values_res = {lbl: [] for lbl in labels}
    group_values_temp = {lbl: [] for lbl in labels}
    res_stats_data = {}
    temp_stats_data = {}

    for gi, cols in enumerate(groups):
        lbl = labels[gi] if gi < len(labels) else f"group{gi}"
        res_vals: List[float] = []
        temp_vals: List[float] = []
        for fname in resistances_by_file:
            for col in cols:
                r = resistances_by_file[fname].get(col)
                if isinstance(r, (int, float)) and math.isfinite(r):
                    res_vals.append(r)
                t = temps_by_file[fname].get(col)
                if isinstance(t, (int, float)) and math.isfinite(t):
                    temp_vals.append(t)
        group_values_res[lbl] = res_vals
        group_values_temp[lbl] = temp_vals
        res_stats_data[lbl] = compute_stats(res_vals)
        temp_stats_data[lbl] = compute_stats(temp_vals)
        dbg_print(debug, f"Group {lbl}: {len(res_vals)} resistances, {len(temp_vals)} temps")

    return groups, labels, res_stats_data, temp_stats_data, group_values_res, group_values_temp

# ----------------- Qt Windows -----------------
class GenericTableWindow(QMainWindow):
    def __init__(self, title: str, headers: List[str], rows: List[List[str]]):
        super().__init__()
        self.setWindowTitle(title)
        self.resize(800, 400)
        table = QTableWidget()
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setRowCount(len(rows))
        for r_idx, row in enumerate(rows):
            for c_idx, item in enumerate(row):
                table.setItem(r_idx, c_idx, QTableWidgetItem(item))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class VoltageTable(QMainWindow):
    def __init__(self, data: Dict[str, Dict[str, float]], columns: List[str]):
        super().__init__()
        self.setWindowTitle("AIN Voltages Table")
        self.resize(1100, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        table.setRowCount(len(data))
        for r_idx, (fname, volts) in enumerate(sorted(data.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                val = volts.get(col, "")
                table.setItem(r_idx, c_idx, QTableWidgetItem(str(val) if val != "" else ""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class LowVoltageTable(QMainWindow):
    def __init__(self, data: Dict[str, Dict[str, float]], columns: List[str]):
        super().__init__()
        self.setWindowTitle("Voltages < {:.3f} V".format(MIN_V_TO_CONVERT))
        self.resize(1100, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        filtered = {f: v for f, v in data.items() if any(isinstance(x, (int, float)) and x < MIN_V_TO_CONVERT for x in v.values())}
        table.setRowCount(len(filtered))
        for r_idx, (fname, volts) in enumerate(sorted(filtered.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                v = volts.get(col, "")
                if isinstance(v, (int, float)) and v < MIN_V_TO_CONVERT:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(f"{v:.6f}"))
                else:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class HighVoltageResistanceTable(QMainWindow):
    def __init__(self, data: Dict[str, Dict[str, float]], columns: List[str], resistances_by_file: Dict[str, Dict[str, Optional[float]]]):
        super().__init__()
        self.setWindowTitle("Voltages → Resistances (Ω)")
        self.resize(1300, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        filtered = {f: v for f, v in data.items() if any(isinstance(x, (int, float)) and x > MIN_V_TO_CONVERT for x in v.values())}
        table.setRowCount(len(filtered))
        for r_idx, (fname, volts) in enumerate(sorted(filtered.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                R = resistances_by_file.get(fname, {}).get(col)
                if isinstance(R, (int, float)) and math.isfinite(R) and R <= MAX_R:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(f"{R:.2f} Ω"))
                else:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class TemperatureTable(QMainWindow):
    def __init__(self, temps_by_file: Dict[str, Dict[str, Optional[float]]], columns: List[str]):
        super().__init__()
        self.setWindowTitle("Temperatures (°C)")
        self.resize(1300, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        filtered = {f: v for f, v in temps_by_file.items() if any(isinstance(x, (int, float)) for x in v.values())}
        table.setRowCount(len(filtered))
        for r_idx, (fname, temps) in enumerate(sorted(filtered.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                t = temps.get(col)
                if isinstance(t, (int, float)) and math.isfinite(t):
                    table.setItem(r_idx, c_idx, QTableWidgetItem(f"{t:.2f} °C"))
                else:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class StatsWindow(QMainWindow):
    def __init__(self, title: str, stats_map: Dict[str, Tuple[str, str, str, str, str]]):
        super().__init__()
        self.setWindowTitle(title)
        self.resize(600, 180)
        headers = ["Group", "Mean", "Min", "Max", "StdDev", "StdDev (%)"]
        rows = []
        for group_label, s in stats_map.items():
            rows.append([group_label, s[0], s[1], s[2], s[3], s[4]])
        table_win = GenericTableWindow(title, headers, rows)
        self.setCentralWidget(table_win.centralWidget())

# ----------------- Self-test -----------------
def selftest_forward_inverse(debug: bool = False):
    """Quick forward/inverse consistency check using the beta model."""
    def r_therm_forward(temp_c):
        t_k = float(temp_c) + 273.15
        return r_0 * math.exp(beta * (1.0 / t_k - 1.0 / t_0))

    print("Self-test: forward (°C) -> R(Ω) -> inverse T_calc (°C)")
    for tc in (-20, 0, 25, 60):
        R = r_therm_forward(tc)
        tc_calc = temp_from_resistance_C(R, debug=debug)
        print(f"{tc:5} °C -> R={R:10.1f} Ω -> T_calc={tc_calc:8.3f} °C")

# ----------------- Main -----------------
def main():
    parser = argparse.ArgumentParser(description="Thermistor readings -> GUI")
    parser.add_argument("--folder", "-f", default=DEFAULT_FOLDER, help="Folder containing .json testdata")
    parser.add_argument("--debug", action="store_true", help="Enable debug printing")
    parser.add_argument("--selftest", action="store_true", help="Run forward/inverse self-test and exit")
    args = parser.parse_args()

    folder = Path(args.folder)
    if args.selftest:
        selftest_forward_inverse(debug=args.debug)
        return

    if not folder.exists() or not folder.is_dir():
        print(f"Folder not found: {folder}")
        return

    data, columns = load_json_files(folder, debug=args.debug)
    if not data:
        print("No JSON files found or no valid data loaded.")
        return

    resistances_by_file, temps_by_file = process_all(data, columns, debug=args.debug)
    groups, labels, res_stats_data, temp_stats_data, group_values_res, group_values_temp = group_and_stats(
        columns, resistances_by_file, temps_by_file, debug=args.debug
    )

    # Launch Qt GUI windows
    app = QApplication(sys.argv)
    win_all = VoltageTable(data, columns)
    win_low = LowVoltageTable(data, columns)
    win_res = HighVoltageResistanceTable(data, columns, resistances_by_file)
    win_temp_table = TemperatureTable(temps_by_file, columns)
    win_res_stats = StatsWindow("Resistance Stats (Ω)", res_stats_data)
    win_temp_stats = StatsWindow("Temperature Stats (°C)", temp_stats_data)

    # Show windows
    win_all.show()
    win_low.show()
    win_res.show()
    win_temp_table.show()
    win_res_stats.show()
    win_temp_stats.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
