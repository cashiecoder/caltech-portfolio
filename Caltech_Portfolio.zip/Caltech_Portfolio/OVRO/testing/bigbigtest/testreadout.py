import os
import json
from datetime import datetime
from labjack import ljm
from functions import printInfo
from variables import connection
from variables.ain_arrays import ain_arrays
import statistics
from sanitycheck import debug_temp

HANDLE_INFO = connection.HANDLE_INFO

try:
    handle = ljm.openS(*HANDLE_INFO)

    print(f"Device opened. Handle: {handle}")
    printInfo(handle)

    # Get device info
    device_info = ljm.getHandleInfo(handle)
    print(f"Device Info: {device_info}")

    channel_name = "AIN127"

    # Read all channels
    value = ljm.eReadName(handle, channel_name)
    print(value)
    debug_temp(value)

    # Close device
    ljm.close(handle)

except Exception as e:
    print(f"Failed to connect or read data:\n{e}")
