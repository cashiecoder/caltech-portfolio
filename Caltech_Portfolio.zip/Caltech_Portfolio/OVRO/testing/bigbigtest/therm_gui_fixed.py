#!/usr/bin/env python3
r"""
Thermistor JSON reader + GUI (PyQt6)

This variant ALWAYS uses:
    V_0 = avg(AIN0, AIN2)
    V_5 = 2 * avg(AIN1, AIN3)

Usage:
    python therm_gui_force_double.py --folder "C:\path\to\testdata" [--debug] [--selftest] [--no-double]
"""
from __future__ import annotations
import argparse
import json
import math
import sys
from pathlib import Path
from statistics import mean, stdev
from typing import Dict, List, Optional, Tuple

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget
)

# try to import user variables.py (thermistor) if present
try:
    from variables import thermistor  # type: ignore
except Exception:
    thermistor = None

# ----------------- Defaults -----------------
DEFAULT_FOLDER = r"C:\Users\thavel\Documents\Steve\LabJackT7\thermistor\thermistor_data"
VOLTAGE_GND_ORDER = ["ain0", "ain1", "ain2", "ain3", "ain103", "ain101"]
MAX_R = 200_000
MIN_V_TO_CONVERT = 0.1
GROUP_LABELS = ["1k", "10k", "32k", "5.5k"]

R_series = float(getattr(thermistor, "R_series", 32400)) if thermistor is not None else 32400.0
beta = float(getattr(thermistor, "beta", 3892)) if thermistor is not None else 3892.0
r_0 = float(getattr(thermistor, "r_0", 10000)) if thermistor is not None else 10000.0
t_0 = getattr(thermistor, "t_0", None) if thermistor is not None else None
if t_0 is None:
    t_0 = 25.0 + 273.15
else:
    t_0 = float(t_0)
    if t_0 < 100.0:
        t_0 = t_0 + 273.15

# ----------------- Helpers -----------------
def parse_voltage(v) -> Optional[float]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        try:
            return float(v)
        except Exception:
            return None
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return None
        if s.count(",") == 1 and s.count(".") == 0:
            s = s.replace(",", ".")
        allowed = set("0123456789+-.eE")
        cleaned = "".join(ch for ch in s if ch in allowed)
        if cleaned == "" or cleaned.lower() in ("na", "nan"):
            return None
        try:
            return float(cleaned)
        except Exception:
            return None
    return None

def dbg_print(enabled: bool, *args, **kwargs):
    if enabled:
        print(*args, **kwargs)

def calc_R_th_from_voltage(V_t: float, V_0: float, V_5: float, R_series_local: float = R_series,
                           debug: bool = False) -> Optional[float]:
    """Compute thermistor resistance from measured V_t using divider formula."""
    if V_0 is None or V_5 is None:
        if debug:
            print("calc_R: missing V_0 or V_5")
        return None
    Vs_local = V_5 - V_0
    V_local = V_t - V_0
    if Vs_local <= 0 or V_local <= 0 or V_local >= Vs_local or math.isclose(Vs_local - V_local, 0.0):
        if debug:
            print(f"calc_R: invalid voltages V_0={V_0!r}, V_5={V_5!r}, V_t={V_t!r} -> Vs={Vs_local!r}, V={V_local!r}")
        return None
    try:
        R_th = (V_local * R_series_local) / (Vs_local - V_local)
    except Exception as e:
        if debug:
            print("calc_R exception:", e)
        return None
    if not math.isfinite(R_th) or R_th <= 0 or R_th > MAX_R:
        if debug:
            print(f"calc_R: out-of-range R_th={R_th!r}")
        return None
    return R_th

def temp_from_resistance_C(R: float, r0: float = r_0, beta_val: float = beta, t0_k: float = t_0,
                           debug: bool = False) -> Optional[float]:
    """Compute temperature in °C from thermistor resistance using the Beta model.
    Inverse of R(T) = R0 * exp[ beta * (1/T - 1/T0) ].
    """
    if R is None or R <= 0:
        return None
    try:
        ln_term = math.log(R / r0)
        invT = (1.0 / t0_k) + (1.0 / beta_val) * ln_term
        if invT <= 0:
            if debug:
                print(f"temp_from_resistance: invalid invT={invT}")
            return None
        T_k = 1.0 / invT
        T_c = T_k - 273.15
        if not math.isfinite(T_c):
            if debug:
                print("temp_from_resistance: result not finite")
            return None
        return T_c
    except Exception as e:
        if debug:
            print("temp_from_resistance exception:", e)
        return None

def compute_stats(values: List[float]) -> Tuple[str, str, str, str, str]:
    if not values:
        return ("", "", "", "", "")
    mu = mean(values)
    mn = min(values)
    mx = max(values)
    sd = stdev(values) if len(values) > 1 else 0.0
    if mu != 0 and math.isfinite(mu):
        sd_pct = (sd / abs(mu)) * 100.0
        sd_pct_str = f"{sd_pct:.4f} %"
    else:
        sd_pct_str = ""
    return (f"{mu:.4f}", f"{mn:.4f}", f"{mx:.4f}", f"{sd:.4f}", sd_pct_str)

# ----------------- Load JSONs -----------------
def load_json_files(folder: Path, debug: bool = False) -> Tuple[Dict[str, Dict[str, Optional[float]]], List[str]]:
    json_files = sorted([p for p in folder.iterdir() if p.suffix.lower() == ".json"])
    data: Dict[str, Dict[str, Optional[float]]] = {}
    columns_list: List[str] = []

    for p in json_files:
        try:
            with open(p, "r") as fh:
                content = json.load(fh)
        except Exception as e:
            dbg_print(debug, f"Failed to open/parse {p}: {e}")
            continue

        voltages: Dict[str, Optional[float]] = {}
        if isinstance(content, dict):
            for section, section_obj in content.items():
                if not isinstance(section_obj, dict):
                    continue
                for key, info in section_obj.items():
                    if not isinstance(info, dict):
                        continue
                    term = info.get("terminal")
                    raw_val = info.get("voltage")
                    if term is None:
                        continue
                    t_lower = str(term).lower()
                    parsed = parse_voltage(raw_val)
                    voltages[t_lower] = parsed
                    if t_lower not in VOLTAGE_GND_ORDER and t_lower not in columns_list:
                        columns_list.append(t_lower)
        elif isinstance(content, list):
            for info in content:
                if not isinstance(info, dict):
                    continue
                term = info.get("terminal")
                raw_val = info.get("voltage")
                if term is None:
                    continue
                t_lower = str(term).lower()
                parsed = parse_voltage(raw_val)
                voltages[t_lower] = parsed
                if t_lower not in VOLTAGE_GND_ORDER and t_lower not in columns_list:
                    columns_list.append(t_lower)
        else:
            dbg_print(debug, f"Unknown JSON format in {p}, skipping")
            continue

        data[p.name] = voltages

    columns = columns_list + [t for t in VOLTAGE_GND_ORDER if any(t == k for v in data.values() for k in v)]
    dbg_print(debug, f"Loaded {len(data)} JSON files, columns: {columns}")
    return data, columns

# ----------------- CORE: ALWAYS DOUBLE V5 -----------------
def process_all_force_double(data: Dict[str, Dict[str, Optional[float]]], columns: List[str],
                             min_v_to_convert: float = MIN_V_TO_CONVERT, debug: bool = False):
    """
    This function ALWAYS uses:
        V_0 = avg(ain0, ain2)
        V_5 = 2 * avg(ain1, ain3)
    Then converts voltages -> R -> T for voltages > min_v_to_convert.
    """
    resistances_by_file: Dict[str, Dict[str, Optional[float]]] = {}
    temps_by_file: Dict[str, Dict[str, Optional[float]]] = {}

    for fname, volts in data.items():
        res_map: Dict[str, Optional[float]] = {}
        temp_map: Dict[str, Optional[float]] = {}

        ain0 = volts.get("ain0")
        ain2 = volts.get("ain2")
        v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
        V_0 = (sum(v0_list) / len(v0_list)) if v0_list else None

        ain1 = volts.get("ain1")
        ain3 = volts.get("ain3")
        v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
        V5_raw = (sum(v5_list) / len(v5_list)) if v5_list else None

        # IMPORTANT: ALWAYS double the measured 2.5V candidate to form the 5V reference
        V_5 = (V5_raw * 2.0) if (V5_raw is not None) else None

        dbg_print(debug, f"[{fname}] V_0={V_0!r}  V5_raw={V5_raw!r}  V_5 (used)={V_5!r}")

        for col in columns:
            raw_v = volts.get(col)
            if not (isinstance(raw_v, (int, float)) and raw_v > min_v_to_convert and (V_0 is not None) and (V_5 is not None)):
                res_map[col] = None
                temp_map[col] = None
                continue

            R_th = calc_R_th_from_voltage(raw_v, V_0, V_5, R_series_local=R_series, debug=debug)
            res_map[col] = R_th
            temp_map[col] = temp_from_resistance_C(R_th, debug=debug) if R_th is not None else None

            if debug:
                dbg_print(debug, f"[{fname}][{col}] raw_v={raw_v:.6f} V_0={V_0:.6f} V_5={V_5:.6f} -> R={R_th!r} T={temp_map[col]!r}")

        resistances_by_file[fname] = res_map
        temps_by_file[fname] = temp_map

    return resistances_by_file, temps_by_file

# ----------------- Grouping / Stats -----------------
def group_and_stats(columns: List[str], resistances_by_file: Dict[str, Dict[str, Optional[float]]],
                    temps_by_file: Dict[str, Dict[str, Optional[float]]], debug: bool = False):
    non_gnd_cols = [c for c in columns if c not in VOLTAGE_GND_ORDER]
    groups = [non_gnd_cols[i::4] for i in range(4)]
    labels = GROUP_LABELS[:len(groups)]

    group_values_res = {lbl: [] for lbl in labels}
    group_values_temp = {lbl: [] for lbl in labels}
    res_stats_data = {}
    temp_stats_data = {}

    for gi, cols in enumerate(groups):
        lbl = labels[gi] if gi < len(labels) else f"group{gi}"
        res_vals: List[float] = []
        temp_vals: List[float] = []
        for fname in resistances_by_file:
            for col in cols:
                r = resistances_by_file[fname].get(col)
                if isinstance(r, (int, float)) and math.isfinite(r):
                    res_vals.append(r)
                t = temps_by_file[fname].get(col)
                if isinstance(t, (int, float)) and math.isfinite(t):
                    temp_vals.append(t)
        group_values_res[lbl] = res_vals
        group_values_temp[lbl] = temp_vals
        res_stats_data[lbl] = compute_stats(res_vals)
        temp_stats_data[lbl] = compute_stats(temp_vals)
        dbg_print(debug, f"Group {lbl}: {len(res_vals)} resistances, {len(temp_vals)} temps")

    return groups, labels, res_stats_data, temp_stats_data, group_values_res, group_values_temp

# ----------------- Qt UI windows (same as before) -----------------
class GenericTableWindow(QMainWindow):
    def __init__(self, title: str, headers: List[str], rows: List[List[str]]):
        super().__init__()
        self.setWindowTitle(title)
        self.resize(800, 400)
        table = QTableWidget()
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setRowCount(len(rows))
        for r_idx, row in enumerate(rows):
            for c_idx, item in enumerate(row):
                table.setItem(r_idx, c_idx, QTableWidgetItem(item))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class VoltageTable(QMainWindow):
    def __init__(self, data: Dict[str, Dict[str, Optional[float]]], columns: List[str]):
        super().__init__()
        self.setWindowTitle("AIN Voltages Table")
        self.resize(1100, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        table.setRowCount(len(data))
        for r_idx, (fname, volts) in enumerate(sorted(data.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                v = volts.get(col)
                table.setItem(r_idx, c_idx, QTableWidgetItem(f"{v:.6f}" if isinstance(v, (int, float)) else ""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class LowVoltageTable(QMainWindow):
    def __init__(self, data: Dict[str, Dict[str, Optional[float]]], columns: List[str], min_v: float):
        super().__init__()
        self.setWindowTitle("Voltages < {:.3f} V".format(min_v))
        self.resize(1100, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        filtered = {f: v for f, v in data.items() if any(isinstance(x, (int, float)) and x < min_v for x in v.values())}
        table.setRowCount(len(filtered))
        for r_idx, (fname, volts) in enumerate(sorted(filtered.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                v = volts.get(col)
                table.setItem(r_idx, c_idx, QTableWidgetItem(f"{v:.6f}" if isinstance(v, (int, float)) and v < min_v else ""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class HighVoltageResistanceTable(QMainWindow):
    def __init__(self, data: Dict[str, Dict[str, Optional[float]]], columns: List[str], resistances_by_file: Dict[str, Dict[str, Optional[float]]]):
        super().__init__()
        self.setWindowTitle("Voltages → Resistances (Ω)")
        self.resize(1300, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        filtered = {f: v for f, v in data.items() if any(isinstance(x, (int, float)) and x > MIN_V_TO_CONVERT for x in v.values())}
        table.setRowCount(len(filtered))
        for r_idx, (fname, volts) in enumerate(sorted(filtered.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                R = resistances_by_file.get(fname, {}).get(col)
                if isinstance(R, (int, float)) and math.isfinite(R) and R <= MAX_R:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(f"{R:.2f} Ω"))
                else:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class TemperatureTable(QMainWindow):
    def __init__(self, temps_by_file: Dict[str, Dict[str, Optional[float]]], columns: List[str]):
        super().__init__()
        self.setWindowTitle("Temperatures (°C)")
        self.resize(1300, 600)
        table = QTableWidget()
        table.setColumnCount(len(columns) + 1)
        table.setHorizontalHeaderLabels(['Filename'] + [c.upper() for c in columns])
        filtered = {f: v for f, v in temps_by_file.items() if any(isinstance(x, (int, float)) for x in v.values())}
        table.setRowCount(len(filtered))
        for r_idx, (fname, temps) in enumerate(sorted(filtered.items())):
            table.setItem(r_idx, 0, QTableWidgetItem(fname))
            for c_idx, col in enumerate(columns, start=1):
                t = temps.get(col)
                if isinstance(t, (int, float)) and math.isfinite(t):
                    table.setItem(r_idx, c_idx, QTableWidgetItem(f"{t:.2f} °C"))
                else:
                    table.setItem(r_idx, c_idx, QTableWidgetItem(""))
        layout = QVBoxLayout()
        layout.addWidget(table)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

class StatsWindow(QMainWindow):
    def __init__(self, title: str, stats_map: Dict[str, Tuple[str, str, str, str, str]]):
        super().__init__()
        self.setWindowTitle(title)
        self.resize(600, 180)
        headers = ["Group", "Mean", "Min", "Max", "StdDev", "StdDev (%)"]
        rows = []
        for group_label, s in stats_map.items():
            rows.append([group_label, s[0], s[1], s[2], s[3], s[4]])
        table_win = GenericTableWindow(title, headers, rows)
        self.setCentralWidget(table_win.centralWidget())

# ----------------- Self-test -----------------
def selftest_forward_inverse(debug: bool = False):
    def r_therm_forward(temp_c):
        t_k = float(temp_c) + 273.15
        return r_0 * math.exp(beta * (1.0 / t_k - 1.0 / t_0))

    print("Self-test: forward (°C) -> R(Ω) -> inverse T_calc (°C)")
    for tc in (-20, 0, 25, 60):
        R = r_therm_forward(tc)
        tc_calc = temp_from_resistance_C(R, debug=debug)
        print(f"{tc:5} °C -> R={R:10.1f} Ω -> T_calc={tc_calc:8.3f} °C")

# ----------------- Main -----------------
def main():
    parser = argparse.ArgumentParser(description="Thermistor readings -> GUI (force double V5)")
    parser.add_argument("--folder", "-f", default=DEFAULT_FOLDER, help="Folder containing .json testdata")
    parser.add_argument("--debug", action="store_true", help="Enable debug printing")
    parser.add_argument("--selftest", action="store_true", help="Run forward/inverse self-test and exit")
    parser.add_argument("--min-v", type=float, default=MIN_V_TO_CONVERT, help="Minimum voltage to attempt conversion")
    parser.add_argument("--no-double", action="store_true", help="If set, do NOT double the measured V5 (for testing). Default is to double.")
    args = parser.parse_args()

    folder = Path(args.folder)
    if args.selftest:
        selftest_forward_inverse(debug=args.debug)
        return

    if not folder.exists() or not folder.is_dir():
        print(f"Folder not found: {folder}")
        return

    data, columns = load_json_files(folder, debug=args.debug)
    if not data:
        print("No JSON files found or no valid data loaded.")
        return

    if args.no_double:
        # fallback to previous behavior for testing: use average as-is (not doubled)
        # but you asked to ALWAYS double — this is only for optional testing.
        def process_all(data_in, cols, min_v_to_convert=args.min_v, debug=args.debug):
            # identical to process_all_force_double but without the *2
            resistances_by_file: Dict[str, Dict[str, Optional[float]]] = {}
            temps_by_file: Dict[str, Dict[str, Optional[float]]] = {}
            for fname, volts in data_in.items():
                res_map: Dict[str, Optional[float]] = {}
                temp_map: Dict[str, Optional[float]] = {}
                ain0 = volts.get("ain0")
                ain2 = volts.get("ain2")
                v0_list = [x for x in (ain0, ain2) if isinstance(x, (int, float))]
                V_0 = (sum(v0_list) / len(v0_list)) if v0_list else None
                ain1 = volts.get("ain1")
                ain3 = volts.get("ain3")
                v5_list = [x for x in (ain1, ain3) if isinstance(x, (int, float))]
                V_5 = (sum(v5_list) / len(v5_list)) if v5_list else None
                dbg_print(debug, f"[{fname}] V_0={V_0!r}  V_5 (used)={V_5!r}")
                for col in cols:
                    raw_v = volts.get(col)
                    if not (isinstance(raw_v, (int, float)) and raw_v > min_v_to_convert and (V_0 is not None) and (V_5 is not None)):
                        res_map[col] = None
                        temp_map[col] = None
                        continue
                    R_th = calc_R_th_from_voltage(raw_v, V_0, V_5, R_series_local=R_series, debug=debug)
                    res_map[col] = R_th
                    temp_map[col] = temp_from_resistance_C(R_th, debug=debug) if R_th is not None else None
                    if debug:
                        dbg_print(debug, f"[{fname}][{col}] raw_v={raw_v:.6f} V_0={V_0:.6f} V_5={V_5:.6f} -> R={R_th!r} T={temp_map[col]!r}")
                resistances_by_file[fname] = res_map
                temps_by_file[fname] = temp_map
            return resistances_by_file, temps_by_file

        resistances_by_file, temps_by_file = process_all(data, columns, debug=args.debug)
    else:
        resistances_by_file, temps_by_file = process_all_force_double(data, columns, min_v_to_convert=args.min_v, debug=args.debug)

    groups, labels, res_stats_data, temp_stats_data, group_values_res, group_values_temp = group_and_stats(
        columns, resistances_by_file, temps_by_file, debug=args.debug
    )

    app = QApplication(sys.argv)
    win_all = VoltageTable(data, columns)
    win_low = LowVoltageTable(data, columns, args.min_v)
    win_res = HighVoltageResistanceTable(data, columns, resistances_by_file)
    win_temp_table = TemperatureTable(temps_by_file, columns)
    win_res_stats = StatsWindow("Resistance Stats (Ω)", res_stats_data)
    win_temp_stats = StatsWindow("Temperature Stats (°C)", temp_stats_data)

    win_all.show()
    #win_low.show()
    win_res.show()
    win_temp_table.show()
    #win_res_stats.show()
    #win_temp_stats.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
